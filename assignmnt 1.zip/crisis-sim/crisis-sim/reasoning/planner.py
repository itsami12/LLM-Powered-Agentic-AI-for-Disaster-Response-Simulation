# reasoning/planner.py
import json
import os
from .react import react_plan
from .reflexion import critique_and_update

def make_plan(context, strategy="react", scratchpad=""):
    """
    Dispatch to different reasoning frameworks based on strategy.
    All LLM calls go through this unified interface.
    """
    
    if strategy == "react":
        kind, payload = react_plan(context, scratchpad=scratchpad)
        
    elif strategy == "react_reflexion":
        # Standard ReAct with reflexion if we have history
        kind, payload = react_plan(context, scratchpad=scratchpad)
        
        # Apply reflexion if we have enough history
        if scratchpad and len(scratchpad.split('\n')) >= 10:
            critique = critique_and_update(scratchpad)
            # Replan with critique in mind
            enhanced_scratchpad = f"{scratchpad}\n\nREFLECTION: {critique}"
            kind, payload = react_plan(context, scratchpad=enhanced_scratchpad)
            
    elif strategy == "cot":
        from .cot import cot_plan
        kind, payload = cot_plan(context, scratchpad=scratchpad)
        
    elif strategy == "plan_execute":
        from .plan_execute import plan_execute_plan
        kind, payload = plan_execute_plan(context, scratchpad=scratchpad)
        
    elif strategy == "tot":
        # Tree-of-Thoughts (simplified version)
        from .tot import tot_plan
        kind, payload = tot_plan(context, scratchpad=scratchpad)
        
    else:
        # Fallback to basic ReAct
        kind, payload = react_plan(context, scratchpad=scratchpad)
    
    # Log the planning call
    _log_planning_call(context, strategy, scratchpad, kind, payload)
    
    if kind == "final":
        try:
            return json.loads(payload)
        except json.JSONDecodeError as e:
            # Log the JSON error and return empty commands
            _log_json_error(payload, str(e))
            return {"commands": []}
    else:
        # For action/observation loops (ReAct), return partial results
        # In a full implementation, you'd handle tool calls here
        return {"commands": []}

def _log_planning_call(context, strategy, scratchpad, kind, payload):
    """Log each planning call for analysis."""
    # Create logs directory structure
    tick = context.get("tick", 0) or 0
    log_dir = f"logs/strategy={strategy}/run={os.getenv('RUN_ID', 'default')}"
    os.makedirs(log_dir, exist_ok=True)
    
    log_entry = {
        "tick": tick,
        "strategy": strategy,
        "context_size": len(str(context)),
        "scratchpad_size": len(scratchpad),
        "response_type": kind,
        "response_size": len(payload),
        "prompt": _build_prompt_summary(context, strategy, scratchpad),
        "response": payload[:500] + "..." if len(payload) > 500 else payload
    }
    
    log_file = f"{log_dir}/tick={tick:03d}.jsonl"
    with open(log_file, "a") as f:
        f.write(json.dumps(log_entry) + "\n")

def _build_prompt_summary(context, strategy, scratchpad):
    """Build a summary of the prompt sent to LLM."""
    return {
        "agents_count": len(context.get("agents", [])),
        "survivors_count": len(context.get("survivors", [])),
        "fires_count": len(context.get("fires", [])),
        "strategy": strategy,
        "has_scratchpad": len(scratchpad) > 0
    }

def _log_json_error(payload, error):
    """Log JSON parsing errors for debugging."""
    error_log = {
        "error_type": "json_parse",
        "payload": payload,
        "error": error
    }
    os.makedirs("logs/errors", exist_ok=True)
    with open("logs/errors/json_errors.jsonl", "a") as f:
        f.write(json.dumps(error_log) + "\n")