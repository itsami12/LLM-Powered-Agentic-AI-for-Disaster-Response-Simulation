import json
from .llm_client import llm_complete

def tot_plan(context, scratchpad: str = ""):
    """Tree-of-Thoughts: Generate and evaluate multiple approaches."""
    
    # Generate approaches
    generation_prompt = f"""
Generate 3 different emergency response strategies:

CONTEXT: {json.dumps(context, indent=1)}

APPROACH 1 - RESCUE_FOCUSED: Prioritize immediate survivor rescue
APPROACH 2 - FIRE_CONTROL: Focus on fire suppression then rescue  
APPROACH 3 - BALANCED: Parallel rescue and fire suppression

For each approach, briefly describe the strategy and expected outcomes.
"""
    
    approaches = llm_complete(generation_prompt, temperature=0.4)
    
    # Evaluate and select
    evaluation_prompt = f"""
Evaluate the three approaches and select the best one:

{approaches}

Current situation: {len(context.get('survivors', []))} survivors, {len(context.get('fires', []))} fires

Select the best approach and generate specific commands:
FinalAnswer: {{"commands": [your commands]}}
"""
    
    response = llm_complete(evaluation_prompt, temperature=0.1)
    
    if "FinalAnswer:" in response:
        answer_part = response.split("FinalAnswer:")[-1].strip()
        try:
            plan = json.loads(answer_part)
            return ("final", json.dumps(plan))
        except json.JSONDecodeError:
            pass
    
    # Fallback
    from .react import enhanced_mock_react
    plan_dict = enhanced_mock_react(context)
    return ("final", json.dumps(plan_dict))