# reasoning/plan_execute.py
import json
from .llm_client import llm_complete

def plan_execute_plan(context, scratchpad: str = ""):
    """
    Plan-and-Execute framework: First create high-level plan, then generate specific actions.
    """
    
    # Phase 1: High-level planning
    planning_prompt = f"""
You are creating a HIGH-LEVEL STRATEGIC PLAN for emergency response.

CONTEXT:
{json.dumps(context, indent=2)}

PREVIOUS ACTIONS:
{scratchpad}

Create a strategic plan with these phases:
1. IMMEDIATE RESCUE (survivors with deadline < 50)
2. FIRE SUPPRESSION (prevent spread)
3. AREA CLEARING (rubble blocking key paths)
4. SYSTEMATIC RESCUE (remaining survivors)
5. RESOURCE MANAGEMENT (recharge, restock)

For each phase, identify:
- Which agents should focus on what
- Key objectives and success criteria
- Resource requirements

Respond with your strategic plan in plain text format.
"""
    
    strategic_plan = llm_complete(planning_prompt, temperature=0.2)
    
    # Phase 2: Tactical execution
    execution_prompt = f"""
Based on the strategic plan below, generate SPECIFIC TACTICAL COMMANDS for this tick.

STRATEGIC PLAN:
{strategic_plan}

CURRENT CONTEXT:
{json.dumps(context, indent=2)}

PREVIOUS ACTIONS:
{scratchpad}

Now generate specific commands for each agent for this single tick:

Rules for command generation:
1. Each agent gets at most ONE command per tick
2. Prioritize the current strategic phase objectives
3. Consider agent capabilities and current state
4. Avoid sending agents to impossible locations

Provide your tactical commands as:
FinalAnswer: {{"commands": [list of command objects]}}

Each command must follow this exact schema:
{{"agent_id": "string", "type": "move|act", "to": [x,y] (for move only), "action_name": "string" (for act only)}}

Available actions:
- Medic: "pickup_survivor", "drop_at_hospital"
- Truck: "extinguish", "clear_rubble"
- Drone: (observation/patrol)
"""
    
    response = llm_complete(execution_prompt, temperature=0.1)
    
    # Extract final answer
    if "FinalAnswer:" in response:
        answer_part = response.split("FinalAnswer:")[-1].strip()
        try:
            plan = json.loads(answer_part)
            return ("final", json.dumps(plan))
        except json.JSONDecodeError:
            # Fallback parsing
            if '"commands"' in answer_part:
                try:
                    start = answer_part.find('[')
                    end = answer_part.rfind(']') + 1
                    if start != -1 and end != 0:
                        commands_json = answer_part[start:end]
                        return ("final", json.dumps({"commands": json.loads(commands_json)}))
                except:
                    pass
    
    return ("final", json.dumps({"commands": []}))