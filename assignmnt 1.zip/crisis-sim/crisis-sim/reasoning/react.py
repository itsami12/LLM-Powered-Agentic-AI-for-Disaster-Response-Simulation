import json
import os
from .llm_client import llm_complete

def react_plan(context, scratchpad: str = ""):
    """Enhanced ReAct planning with better coordination."""
    provider = os.getenv("LLM_PROVIDER", "ollama").lower()
    
    if provider == "ollama":
        plan_dict = enhanced_mock_react(context)
        return ("final", json.dumps(plan_dict))
    
    return llm_react_plan(context, scratchpad)

def llm_react_plan(context, scratchpad: str = ""):
    """LLM-based ReAct reasoning."""
    prompt = f"""
You are coordinating emergency response. Current situation:

CRITICAL INFO:
- Tick: {context.get('tick', 0)}
- Survivors remaining: {len(context.get('survivors', []))}
- Active fires: {len(context.get('fires', []))}
- Rescued so far: {context.get('metrics', {}).get('rescued', 0)}
- Deaths: {context.get('metrics', {}).get('deaths', 0)}

AGENTS:
{json.dumps(context.get('agents', []), indent=2)}

SURVIVORS (urgent first):
{json.dumps(sorted(context.get('survivors', []), key=lambda s: s.get('deadline', 999)), indent=2)}

RECENT ACTIONS: {scratchpad}

STRATEGY: Prioritize survivors with deadline < 100, then fire suppression, then rubble clearing.

Provide commands in exact format:
FinalAnswer: {{"commands": [list]}}

Each command: {{"agent_id": "string", "type": "move|act", "to": [x,y] (move only), "action_name": "string" (act only)}}
"""
    
    response = llm_complete(prompt, temperature=0.1)
    
    if "FinalAnswer:" in response:
        answer_part = response.split("FinalAnswer:")[-1].strip()
        try:
            plan = json.loads(answer_part)
            return ("final", json.dumps(plan))
        except json.JSONDecodeError:
            pass
    
    # Fallback to enhanced mock
    plan_dict = enhanced_mock_react(context)
    return ("final", json.dumps(plan_dict))

def enhanced_mock_react(context):
    """Enhanced planning with explicit rubble clearing."""
    commands = []
    agents = context.get("agents", [])
    survivors = context.get("survivors", [])
    fires = context.get("fires", [])
    rubble = context.get("rubble", [])
    hospitals = context.get("hospitals", [])
    depot = context.get("depot", [1, 1])
    
    # Debug info
    tick = context.get("tick", 0)
    
    # Sort survivors by urgency
    urgent_survivors = [s for s in survivors if s.get("deadline", 999) < 120]
    urgent_survivors.sort(key=lambda s: s.get("deadline", 999))
    
    fire_positions = set(tuple(f) for f in fires)
    rubble_positions = set(tuple(r) for r in rubble)
    hospital_positions = [tuple(h["pos"]) for h in hospitals]
    depot_pos = tuple(depot)
    
    assigned_targets = set()
    
    for agent in agents:
        aid = agent["id"]
        kind = agent.get("kind", "unknown")
        pos = tuple(agent.get("pos", [0, 0]))
        
        if kind == "medic":
            carrying = agent.get("carrying", False)
            stamina_pct = agent.get("stamina_pct", 100)
            
            if stamina_pct < 50:
                if pos == depot_pos:
                    commands.append({"agent_id": aid, "type": "act", "action_name": "recharge_stamina"})
                else:
                    next_pos = _safe_move_toward(pos, depot_pos, fire_positions)
                    commands.append({"agent_id": aid, "type": "move", "to": list(next_pos)})
                continue
            
            if carrying:
                if pos in hospital_positions:
                    commands.append({"agent_id": aid, "type": "act", "action_name": "drop_at_hospital"})
                else:
                    best_hospital = _choose_best_hospital(pos, hospitals)
                    if best_hospital:
                        next_pos = _safe_move_toward(pos, best_hospital, fire_positions)
                        commands.append({"agent_id": aid, "type": "move", "to": list(next_pos)})
            else:
                # Check for survivor at current position first
                if _has_survivor_at(pos, survivors):
                    commands.append({"agent_id": aid, "type": "act", "action_name": "pickup_survivor"})
                    assigned_targets.add(pos)
                else:
                    # Move to best available survivor
                    available_survivors = [s for s in urgent_survivors 
                                         if tuple(s["pos"]) not in assigned_targets]
                    
                    if available_survivors:
                        target_survivor = _choose_best_survivor(pos, available_survivors)
                        target_pos = tuple(target_survivor["pos"])
                        assigned_targets.add(target_pos)
                        next_pos = _safe_move_toward(pos, target_pos, fire_positions)
                        commands.append({"agent_id": aid, "type": "move", "to": list(next_pos)})
        
        elif kind == "truck":
            water = agent.get("water", 30)
            fuel = agent.get("fuel", 50)
            tools = agent.get("tools", 10)
            
            # More aggressive resupply logic
            needs_resupply = (fuel < 20 or (water < 10 and len(fires) > 0) or 
                            (tools < 5 and len(rubble) > 0))
            
            if needs_resupply:
                if pos == depot_pos:
                    commands.append({"agent_id": aid, "type": "act", "action_name": "refuel"})
                else:
                    next_pos = _safe_move_toward(pos, depot_pos, fire_positions)
                    commands.append({"agent_id": aid, "type": "move", "to": list(next_pos)})
                continue
            
            # Action priority: current position first, then movement
            if pos in fire_positions and water > 5:
                commands.append({"agent_id": aid, "type": "act", "action_name": "extinguish"})
                assigned_targets.add(pos)
            elif pos in rubble_positions and tools > 2:
                commands.append({"agent_id": aid, "type": "act", "action_name": "clear_rubble"})
                assigned_targets.add(pos)
            else:
                # Movement priorities: fires first, then rubble
                if len(fires) > 0 and water > 5:
                    available_fires = [f for f in fires if tuple(f) not in assigned_targets]
                    if available_fires:
                        target_fire = _nearest_point(pos, [tuple(f) for f in available_fires])
                        if target_fire:
                            assigned_targets.add(target_fire)
                            next_pos = _move_toward(pos, target_fire)
                            commands.append({"agent_id": aid, "type": "move", "to": list(next_pos)})
                
                elif len(rubble) > 0 and tools > 2:
                    available_rubble = [r for r in rubble if tuple(r) not in assigned_targets]
                    if available_rubble:
                        target_rubble = _nearest_point(pos, [tuple(r) for r in available_rubble])
                        if target_rubble:
                            assigned_targets.add(target_rubble)
                            next_pos = _move_toward(pos, target_rubble)
                            commands.append({"agent_id": aid, "type": "move", "to": list(next_pos)})
        
        elif kind == "drone":
            battery_pct = agent.get("battery_pct", 100)
            
            if battery_pct < 35:
                if pos == depot_pos:
                    commands.append({"agent_id": aid, "type": "act", "action_name": "recharge_battery"})
                else:
                    next_pos = _safe_move_toward(pos, depot_pos, fire_positions)
                    commands.append({"agent_id": aid, "type": "move", "to": list(next_pos)})
            else:
                # Survey areas with survivors
                if urgent_survivors:
                    target_area = tuple(urgent_survivors[0]["pos"])
                    next_pos = _safe_move_toward(pos, target_area, fire_positions)
                    commands.append({"agent_id": aid, "type": "move", "to": list(next_pos)})
    
    return {"commands": commands}

def _has_survivor_at(pos, survivors):
    """Check if there's a survivor at given position."""
    for survivor in survivors:
        if tuple(survivor["pos"]) == pos:
            return True
    return False

def _safe_move_toward(start, goal, obstacles):
    """Move toward goal while avoiding obstacles."""
    sx, sy = start
    gx, gy = goal
    
    # Possible moves in order of preference
    moves = []
    if sx < gx:
        moves.append((sx + 1, sy))
    elif sx > gx:
        moves.append((sx - 1, sy))
    
    if sy < gy:
        moves.append((sx, sy + 1))
    elif sy > gy:
        moves.append((sx, sy - 1))
    
    # Choose first move that avoids obstacles
    for move in moves:
        if move not in obstacles:
            return move
    
    # If all preferred moves blocked, try any adjacent cell
    for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
        move = (sx + dx, sy + dy)
        if move not in obstacles:
            return move
    
    return start  # Stay put if all moves blocked

def _move_toward(start, goal):
    """Simple movement toward goal."""
    sx, sy = start
    gx, gy = goal
    
    if sx < gx:
        return (sx + 1, sy)
    elif sx > gx:
        return (sx - 1, sy)
    elif sy < gy:
        return (sx, sy + 1)
    elif sy > gy:
        return (sx, sy - 1)
    else:
        return start

def _nearest_point(pos, points):
    """Find nearest point from list."""
    if not points:
        return None
    return min(points, key=lambda p: abs(pos[0] - p[0]) + abs(pos[1] - p[1]))

def _choose_best_hospital(pos, hospitals):
    """Choose hospital with best distance/queue combination."""
    if not hospitals:
        return None
    
    best_hospital = None
    best_score = float('inf')
    
    for hospital in hospitals:
        hospital_pos = tuple(hospital["pos"])
        distance = abs(pos[0] - hospital_pos[0]) + abs(pos[1] - hospital_pos[1])
        queue_length = hospital.get("queue_len", 0)
        
        score = distance + queue_length * 2
        
        if score < best_score:
            best_score = score
            best_hospital = hospital_pos
    
    return best_hospital

def _choose_best_survivor(pos, survivors):
    """Choose best survivor based on urgency and distance."""
    if not survivors:
        return None
    
    best_survivor = None
    best_score = float('inf')
    
    for survivor in survivors:
        survivor_pos = tuple(survivor["pos"])
        distance = abs(pos[0] - survivor_pos[0]) + abs(pos[1] - survivor_pos[1])
        deadline = survivor.get("deadline", 999)
        
        # Higher urgency factor for critical survivors
        urgency_factor = max(1, 200 - deadline) / 20
        score = distance / urgency_factor
        
        if score < best_score:
            best_score = score
            best_survivor = survivor
    
    return best_survivor

def _choose_strategic_fire(pos, fires, survivors):
    """Choose fire that's strategically important (near survivors)."""
    if not fires:
        return None
    
    best_fire = None
    best_score = float('inf')
    
    for fire in fires:
        fire_pos = tuple(fire)
        distance = abs(pos[0] - fire_pos[0]) + abs(pos[1] - fire_pos[1])
        
        # Check if fire is near survivors
        nearby_survivors = sum(1 for s in survivors 
                              if abs(s["pos"][0] - fire_pos[0]) + abs(s["pos"][1] - fire_pos[1]) <= 3)
        
        # Prioritize fires near survivors
        strategic_value = max(1, nearby_survivors * 3)
        score = distance / strategic_value
        
        if score < best_score:
            best_score = score
            best_fire = fire_pos
    
    return best_fire

def _survivor_at_position(pos, survivors):
    """Find survivor at given position."""
    for survivor in survivors:
        if tuple(survivor["pos"]) == pos:
            return survivor
    return None

def _has_nearby_rubble(context, pos):
    """Check if there's rubble nearby."""
    rubble_positions = context.get("rubble", [])
    for rubble in rubble_positions:
        if abs(pos[0] - rubble[0]) + abs(pos[1] - rubble[1]) <= 2:
            return True
    return False