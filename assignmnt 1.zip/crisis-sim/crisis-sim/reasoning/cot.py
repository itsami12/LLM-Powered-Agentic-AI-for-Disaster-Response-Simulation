import json
from .llm_client import llm_complete

def cot_plan(context, scratchpad: str = ""):
    """Chain-of-Thought planning with step-by-step reasoning."""
    
    prompt = f"""
You are an emergency response coordinator. Think through this step-by-step:

SITUATION ANALYSIS:
Current tick: {context.get('tick', 0)}
Survivors remaining: {len(context.get('survivors', []))}
Active fires: {len(context.get('fires', []))}
Agents available: {len(context.get('agents', []))}

STEP 1 - PRIORITY ASSESSMENT:
Identify the most urgent survivors (deadline < 100) and immediate threats.

STEP 2 - RESOURCE ALLOCATION:
Determine which agents should focus on what tasks based on their current state.

STEP 3 - COORDINATION STRATEGY:
Plan coordinated actions to maximize efficiency and prevent conflicts.

STEP 4 - COMMAND GENERATION:
Generate specific commands for each agent.

Context: {json.dumps(context, indent=1)}
Recent actions: {scratchpad}

Think through each step, then provide:
FinalAnswer: {{"commands": [your commands]}}
"""
    
    response = llm_complete(prompt, temperature=0.2)
    
    if "FinalAnswer:" in response:
        answer_part = response.split("FinalAnswer:")[-1].strip()
        try:
            plan = json.loads(answer_part)
            return ("final", json.dumps(plan))
        except json.JSONDecodeError:
            pass
    
    # Fallback
    from .react import enhanced_mock_react
    plan_dict = enhanced_mock_react(context)
    return ("final", json.dumps(plan_dict))

