import argparse
import os
import json
import csv
import yaml
import pandas as pd
from pathlib import Path
from tqdm import trange

# Add parent directory to path for imports
import sys
sys.path.append('..')
from main import run_episode

def run_experiments():
    """Run complete experimental evaluation with CSV generation."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_seeds", type=int, default=3, help="Number of seeds per condition")
    parser.add_argument("--maps", nargs="+", default=["configs/map_hard.yaml"])
    parser.add_argument("--strategies", nargs="+", default=["react"])
    parser.add_argument("--providers", nargs="+", default=["ollama"])
    parser.add_argument("--ticks", type=int, default=150)
    parser.add_argument("--output_dir", type=str, default="results")
    args = parser.parse_args()

    # Create directories
    os.makedirs(f"{args.output_dir}/raw", exist_ok=True)
    os.makedirs(f"{args.output_dir}/agg", exist_ok=True)
    
    # Results collection
    all_results = []
    run_id = 0
    
    total_runs = len(args.maps) * len(args.strategies) * len(args.providers) * args.n_seeds
    progress_bar = trange(total_runs, desc="Running experiments")
    
    for map_path in args.maps:
        map_name = Path(map_path).stem
        
        for strategy in args.strategies:
            for provider in args.providers:
                for seed_idx in range(args.n_seeds):
                    seed = 1000 + seed_idx
                    run_id += 1
                    
                    try:
                        # Run experiment
                        metrics = run_episode(
                            map_path=map_path,
                            seed=seed,
                            ticks=args.ticks,
                            provider=provider,
                            strategy=strategy,
                            render=False
                        )
                        
                        # Create result record
                        result = {
                            "run_id": run_id,
                            "seed": seed,
                            "provider": provider,
                            "strategy": strategy,
                            "map": map_name,
                            "rescued": metrics.get("rescued", 0),
                            "deaths": metrics.get("deaths", 0),
                            "avg_rescue_time": metrics.get("avg_rescue_time", 0.0),
                            "fires_extinguished": metrics.get("fires_extinguished", 0),
                            "roads_cleared": metrics.get("roads_cleared", 0),
                            "energy_used": metrics.get("energy_used", 0),
                            "crisis_score": 3 * metrics.get("rescued", 0) - 5 * metrics.get("deaths", 0)
                        }
                        
                        all_results.append(result)
                        
                        # Save individual result
                        with open(f"{args.output_dir}/raw/run_{run_id:04d}.json", "w") as f:
                            json.dump(result, f, indent=2)
                            
                    except Exception as e:
                        print(f"Error in run {run_id}: {e}")
                    
                    progress_bar.update(1)
    
    progress_bar.close()
    
    # Generate CSV files
    if all_results:
        df = pd.DataFrame(all_results)
        
        # Save complete results
        df.to_csv(f"{args.output_dir}/agg/all_results.csv", index=False)
        
        # Create summary
        summary = df.groupby(['strategy', 'provider', 'map']).agg({
            'rescued': ['mean', 'std'],
            'deaths': ['mean', 'std'], 
            'crisis_score': ['mean', 'std'],
            'fires_extinguished': ['mean', 'std']
        }).round(3)
        
        summary.to_csv(f"{args.output_dir}/agg/summary.csv")
        
        print(f"\nExperiments Complete!")
        print(f"Total runs: {len(all_results)}")
        print(f"Results saved to: {args.output_dir}/")
        print(f"Average rescued: {df['rescued'].mean():.1f}")
        print(f"Average deaths: {df['deaths'].mean():.1f}")
        
        # Generate plots
        try:
            generate_plots(df, args.output_dir)
        except Exception as e:
            print(f"Plot generation failed: {e}")
    
    else:
        print("No successful runs completed.")

def generate_plots(df, output_dir):
    """Generate evaluation plots."""
    import matplotlib.pyplot as plt
    import seaborn as sns
    
    os.makedirs(f"{output_dir}/plots", exist_ok=True)
    
    # Crisis score comparison
    plt.figure(figsize=(10, 6))
    summary_plot = df.groupby(['strategy', 'provider'])['crisis_score'].mean().reset_index()
    labels = summary_plot.apply(lambda r: f"{r['strategy']}\n{r['provider']}", axis=1)
    plt.bar(labels, summary_plot['crisis_score'])
    plt.title('Crisis Response Performance by Strategy')
    plt.ylabel('Crisis Score (Higher = Better)')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(f"{output_dir}/plots/crisis_score_comparison.png", dpi=300)
    plt.close()
    
    # Rescued vs Deaths scatter
    plt.figure(figsize=(10, 6))
    plt.scatter(df['rescued'], df['deaths'], alpha=0.7, c=df['crisis_score'], cmap='RdYlGn')
    plt.xlabel('Survivors Rescued')
    plt.ylabel('Deaths')
    plt.title('Rescue Effectiveness')
    plt.colorbar(label='Crisis Score')
    plt.tight_layout()
    plt.savefig(f"{output_dir}/plots/rescue_vs_deaths.png", dpi=300)
    plt.close()
    
    # Performance over time (if multiple runs)
    if len(df) > 1:
        plt.figure(figsize=(12, 4))
        
        plt.subplot(1, 3, 1)
        df.boxplot(column='rescued', by='strategy', ax=plt.gca())
        plt.title('Rescued by Strategy')
        plt.suptitle('')
        
        plt.subplot(1, 3, 2) 
        df.boxplot(column='deaths', by='strategy', ax=plt.gca())
        plt.title('Deaths by Strategy')
        plt.suptitle('')
        
        plt.subplot(1, 3, 3)
        df.boxplot(column='fires_extinguished', by='strategy', ax=plt.gca())
        plt.title('Fires Extinguished by Strategy')
        plt.suptitle('')
        
        plt.tight_layout()
        plt.savefig(f"{output_dir}/plots/performance_boxplots.png", dpi=300)
        plt.close()
    
    print(f"Plots saved to: {output_dir}/plots/")

if __name__ == "__main__":
    run_experiments()