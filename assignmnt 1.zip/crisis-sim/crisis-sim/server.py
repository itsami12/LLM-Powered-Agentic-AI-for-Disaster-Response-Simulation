# server.py — Mesa 1.2.1 compatible, robust config handling

import os
import yaml
from typing import Dict, Tuple, Iterable
from mesa.visualization.modules import CanvasGrid, ChartModule, TextElement
from mesa.visualization.ModularVisualization import ModularServer
from env.world import CrisisModel
from env.agents import DroneAgent, MedicAgent, TruckAgent, Survivor

MAP_PATH = "configs/map_small.yaml"  # change if needed
SEED = 42
CANVAS_W = 600
CANVAS_H = 600

# ---------------- Enhanced Portrayal ----------------

def agent_portrayal(agent):
    if agent is None:
        return
    
    portrayal = {"Layer": 1, "Filled": "true"}

    # Agent-based entities
    if isinstance(agent, DroneAgent):
        portrayal.update({
            "Shape": "triangle",
            "Color": "#00bcd4",  # Cyan
            "scale": 0.8,
            "heading_x": 0.0, 
            "heading_y": 1.0
        })
        portrayal["Layer"] = 4  # Top layer for flying drones

    elif isinstance(agent, MedicAgent):
        # Color based on carrying status
        color = "#2ecc71" if not getattr(agent, "carrying", False) else "#1e8449"  # Green/Dark Green
        portrayal.update({
            "Shape": "circle", 
            "Color": color, 
            "r": 0.5
        })
        portrayal["Layer"] = 3

    elif isinstance(agent, TruckAgent):
        portrayal.update({
            "Shape": "rect", 
            "Color": "#3498db",  # Blue
            "w": 0.9, 
            "h": 0.9
        })
        portrayal["Layer"] = 2

    elif isinstance(agent, Survivor):
        # Color survivors by urgency
        urgency_colors = {
            "critical": "#e74c3c",    # Red - very urgent
            "urgent": "#f39c12",      # Orange - urgent  
            "stable": "#f1c40f"       # Yellow - stable
        }
        
        if hasattr(agent, 'life_deadline'):
            if agent.life_deadline < 50:
                urgency = "critical"
            elif agent.life_deadline < 100:
                urgency = "urgent"
            else:
                urgency = "stable"
        else:
            urgency = "stable"
            
        portrayal.update({
            "Shape": "circle",
            "Color": urgency_colors[urgency],
            "r": 0.35
        })
        portrayal["Layer"] = 1

    return portrayal

def cell_portrayal(x, y, model):
    """Enhanced cell portrayal for terrain features."""
    cell_type = model.cell_type(x, y)
    
    if cell_type == "hospital":
        return {
            "Shape": "rect",
            "Color": "#27ae60",  # Dark green
            "w": 1.0,
            "h": 1.0,
            "Layer": 0,
            "Filled": "true",
            "stroke_color": "#ffffff",
            "stroke_width": 2
        }
    elif cell_type == "fire":
        return {
            "Shape": "circle",
            "Color": "#e74c3c",  # Red
            "r": 0.8,
            "Layer": 1,
            "Filled": "true"
        }
    elif cell_type == "rubble":
        return {
            "Shape": "rect",
            "Color": "#7f8c8d",  # Gray
            "w": 0.8,
            "h": 0.8,
            "Layer": 0,
            "Filled": "true"
        }
    elif cell_type == "depot":
        return {
            "Shape": "rect",
            "Color": "#9b59b6",  # Purple
            "w": 1.0,
            "h": 1.0,
            "Layer": 0,
            "Filled": "true",
            "stroke_color": "#ffffff",
            "stroke_width": 2
        }
    elif cell_type == "building":
        return {
            "Shape": "rect",
            "Color": "#34495e",  # Dark gray
            "w": 0.9,
            "h": 0.9,
            "Layer": 0,
            "Filled": "true"
        }
    
    return None  # Empty/road cells

def combined_portrayal(agent_or_cell):
    """Combined portrayal function for both agents and cells."""
    # If it's an agent, use agent portrayal
    if hasattr(agent_or_cell, 'unique_id'):
        return agent_portrayal(agent_or_cell)
    
    # Otherwise it's a position tuple for cell portrayal
    if isinstance(agent_or_cell, tuple) and len(agent_or_cell) == 3:
        x, y, model = agent_or_cell
        return cell_portrayal(x, y, model)
    
    return None

# Enhanced CanvasGrid that shows both agents and terrain
class EnhancedCanvasGrid(CanvasGrid):
    def render(self, model):
        grid_state = []
        
        # First, add all terrain features
        for y in range(model.grid.height):
            for x in range(model.grid.width):
                cell_type = model.cell_type(x, y)
                if cell_type not in ["road", "empty", None]:
                    cell_portrayal_data = cell_portrayal(x, y, model)
                    if cell_portrayal_data:
                        cell_portrayal_data.update({"x": x, "y": y})
                        grid_state.append(cell_portrayal_data)
        
        # Then add all agents
        for cell_contents, pos in model.grid.coord_iter():
            x, y = pos  # Unpack the position tuple
            for agent in cell_contents:
                agent_portrayal_data = agent_portrayal(agent)
                if agent_portrayal_data:
                    agent_portrayal_data.update({"x": x, "y": y})
                    grid_state.append(agent_portrayal_data)
        
        return grid_state
# ---------------- Config helpers (unchanged) ----------------

def load_cfg(path: str) -> Dict:
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def _iter_points_from_cfg(cfg: Dict) -> Iterable[Tuple[int, int]]:
    depot = cfg.get("depot")
    if isinstance(depot, (list, tuple)) and len(depot) == 2:
        yield (int(depot[0]), int(depot[1]))

    for key in ("hospitals", "rubble", "initial_fires", "buildings"):
        for item in cfg.get(key, []) or []:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                yield (int(item[0]), int(item[1]))

    for s in (cfg.get("survivors_list") or []):
        if isinstance(s, dict) and "pos" in s and isinstance(s["pos"], (list, tuple)) and len(s["pos"]) == 2:
            yield (int(s["pos"][0]), int(s["pos"][1]))
        elif isinstance(s, (list, tuple)) and len(s) == 2:
            yield (int(s[0]), int(s[1]))

def infer_grid_size(cfg: Dict, default: Tuple[int, int] = (20, 20)) -> Tuple[int, int]:
    grid = cfg.get("grid") or {}
    if isinstance(grid, dict) and "w" in grid and "h" in grid:
        return int(grid["w"]), int(grid["h"])

    if "width" in cfg and "height" in cfg:
        return int(cfg["width"]), int(cfg["height"])

    max_x = max_y = -1
    for (x, y) in _iter_points_from_cfg(cfg):
        if x > max_x: max_x = x
        if y > max_y: max_y = y
    if max_x >= 0 and max_y >= 0:
        return max_x + 1, max_y + 1

    return default

# ---------------- Enhanced UI panels ----------------

class EnhancedStatsPanel(TextElement):
    def render(self, model) -> str:
        # Count survivors still on the map (not picked, not dead)
        survivors_on_map = sum(
            1 for a in model.schedule.agents
            if isinstance(a, Survivor)
            and not getattr(a, "_picked", False)
            and not getattr(a, "_dead", False)
        )

        # Count survivors currently being carried by medics
        survivors_carried = sum(
            1 for a in model.schedule.agents
            if hasattr(a, "kind") and a.kind == "medic" 
            and getattr(a, "carrying", False)
        )

        # Count survivors waiting in hospital queues
        survivors_in_queues = sum(len(q) for q in getattr(model, "hospital_queues", {}).values())
        
        # Count active fires
        active_fires = sum(
            1 for y in range(model.height) 
            for x in range(model.width) 
            if model.cell_types[y][x] == "fire"
        )
        
        # Count rubble blocks
        rubble_blocks = sum(
            1 for y in range(model.height)
            for x in range(model.width)
            if model.cell_types[y][x] == "rubble"
        )
        
        # Count battery recharges (approximated by drones at depot with high battery)
        battery_recharges = sum(
            1 for a in model.schedule.agents
            if hasattr(a, "kind") and a.kind == "drone"
            and model.cell_type(a.pos[0], a.pos[1]) == "depot"
            and getattr(a, "battery", 0) > 90
        )

        return (
            f"<div style='font-family: monospace; line-height: 1.6;'>"
            f"<strong>Tick {getattr(model, 'time', 0)}</strong><br/>"
            f"Survivors on map: <span style='color: #f39c12;'>{survivors_on_map}</span><br/>"
            f"Carried by medics: <span style='color: #2ecc71;'>{survivors_carried}</span><br/>"
            f"In hospital queues: <span style='color: #3498db;'>{survivors_in_queues}</span><br/>"
            f"Rescued (admitted): <span style='color: #27ae60;'>{model.rescued}</span><br/>"
            f"Deaths: <span style='color: #e74c3c;'>{model.deaths}</span><br/>"
            f"Active fires: <span style='color: #e74c3c;'>{active_fires}</span><br/>"
            f"Fires extinguished: <span style='color: #3498db;'>{model.fires_extinguished}</span><br/>"
            f"Rubble blocks: <span style='color: #7f8c8d;'>{rubble_blocks}</span><br/>"
            f"Roads cleared: <span style='color: #27ae60;'>{model.roads_cleared}</span><br/>"
            f"Battery recharges: <span style='color: #9b59b6;'>{battery_recharges}</span><br/>"
            f"Hospital overflows: <span style='color: #e67e22;'>{getattr(model, 'hospital_overflow_events', 0)}</span>"
            f"</div>"
        )

class EnhancedLegendPanel(TextElement):
    def render(self, model) -> str:
        return (
            '<div style="font-family: sans-serif; line-height: 1.8; margin: 8px 0; padding: 10px; background: #f8f9fa; border-radius: 4px;">'
            '<strong style="font-size: 14px;">Entity Legend</strong><br/>'
            
            # Agents
            '<div style="margin: 6px 0;">'
            '<span style="display:inline-block;width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:10px solid #00bcd4;margin:0 8px 0 4px;vertical-align:middle;"></span>'
            '<strong>Drone</strong> (cyan triangle)<br/>'
            '<span style="display:inline-block;width:10px;height:10px;background:#2ecc71;border-radius:50%;margin:0 8px 0 4px;"></span>'
            '<strong>Medic</strong> (green circle, dark when carrying)<br/>'
            '<span style="display:inline-block;width:12px;height:8px;background:#3498db;margin:0 8px 0 4px;"></span>'
            '<strong>Truck</strong> (blue rectangle)<br/>'
            '<span style="display:inline-block;width:8px;height:8px;background:#e74c3c;border-radius:50%;margin:0 8px 0 4px;"></span>'
            '<span style="color:#e74c3c;">Critical</span> '
            '<span style="display:inline-block;width:8px;height:8px;background:#f39c12;border-radius:50%;margin:0 4px;"></span>'
            '<span style="color:#f39c12;">Urgent</span> '
            '<span style="display:inline-block;width:8px;height:8px;background:#f1c40f;border-radius:50%;margin:0 4px;"></span>'
            '<span style="color:#f1c40f;">Stable</span> '
            '<strong>Survivors</strong>'
            '</div>'
            
            # Terrain
            '<div style="margin: 6px 0;">'
            '<span style="display:inline-block;width:12px;height:12px;background:#27ae60;margin:0 8px 0 4px;border:1px solid #fff;"></span>'
            '<strong>Hospital</strong> '
            '<span style="display:inline-block;width:12px;height:12px;background:#9b59b6;margin:0 8px 0 12px;border:1px solid #fff;"></span>'
            '<strong>Depot</strong><br/>'
            '<span style="display:inline-block;width:10px;height:10px;background:#e74c3c;border-radius:50%;margin:0 8px 0 4px;"></span>'
            '<strong>Fire</strong> '
            '<span style="display:inline-block;width:10px;height:8px;background:#7f8c8d;margin:0 8px 0 12px;"></span>'
            '<strong>Rubble</strong> '
            '<span style="display:inline-block;width:10px;height:8px;background:#34495e;margin:0 8px 0 12px;"></span>'
            '<strong>Building</strong>'
            '</div>'
            '</div>'
        )

# ---------------- Launch ----------------

def launch(port: int = 8521):
    cfg = load_cfg(MAP_PATH)
    width, height = infer_grid_size(cfg, default=(20, 20))

    # Use enhanced grid that shows both agents and terrain
    grid = EnhancedCanvasGrid(agent_portrayal, width, height, CANVAS_W, CANVAS_H)
    
    # Enhanced charts with more metrics
    charts = ChartModule(
        [
            {"Label": "rescued", "Color": "#27ae60"},      # Green
            {"Label": "deaths", "Color": "#e74c3c"},       # Red  
            {"Label": "fires_extinguished", "Color": "#3498db"},  # Blue
            {"Label": "roads_cleared", "Color": "#f39c12"}, # Orange
        ],
        data_collector_name="datacollector",
        canvas_height=300,
        canvas_width=500
    )

    legend = EnhancedLegendPanel()
    stats = EnhancedStatsPanel()

    server = ModularServer(
        CrisisModel,
        [legend, stats, grid, charts],  # Top-to-bottom in UI
        "Enhanced CrisisSim - Complete Entity Visualization",
        {
            "width": width, 
            "height": height, 
            "rng_seed": SEED, 
            "config": cfg, 
            "render": True
        },
    )
    server.port = port
    print(f"Starting enhanced web UI at http://127.0.0.1:{port}")
    print("Features: Complete entity visualization, enhanced stats, real-time charts")
    print("Press Ctrl+C to stop")
    server.launch()

if __name__ == "__main__":
    launch(port=8522)  # Different port to avoid conflicts