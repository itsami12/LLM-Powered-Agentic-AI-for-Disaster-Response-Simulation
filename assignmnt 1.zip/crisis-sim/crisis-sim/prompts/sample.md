# Sample Prompts

Keep your system/user prompts here for transparency and experiments.
