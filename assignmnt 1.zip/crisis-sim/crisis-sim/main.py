import argparse, os, json, yaml
from pathlib import Path
from env.world import CrisisModel
from reasoning.planner import make_plan

def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f) or {}

def run_episode(map_path, seed=42, ticks=200, provider="mock", strategy="react", log_path=None, render=False):
    os.environ["LLM_PROVIDER"] = provider
    cfg = load_config(map_path)
    W = cfg.get("width", 20)
    H = cfg.get("height", 20)
    model = CrisisModel(W, H, rng_seed=seed, config=cfg, render=render)
    
    if log_path is None:
        log_path = f"logs/seed_{seed}_{Path(map_path).stem}_{provider}_{strategy}.txt"
    os.makedirs(Path(log_path).parent, exist_ok=True)
    
    logf = open(log_path, "w", buffering=1, encoding="utf-8")
    transcript = []
    
    print(f"Starting simulation: {ticks} ticks, {len([a for a in model.schedule.agents if hasattr(a, 'life_deadline')])} survivors")
    
    for t in range(ticks):
        # Use enhanced state summary
        state = model.get_enhanced_state_summary() if hasattr(model, 'get_enhanced_state_summary') else model.summarize_state()
        
        plan = make_plan(state, strategy=strategy, scratchpad="\n".join(transcript[-10:]))
        cmds = plan.get("commands", [])
        model.set_plan(cmds)
        
        # Enhanced logging
        logf.write(f"=== Tick {t} ===\n")
        logf.write(f"Survivors: {len(state.get('survivors', []))}, ")
        logf.write(f"Fires: {len(state.get('fires', []))}, ")
        logf.write(f"Tool calls: {state.get('metrics', {}).get('tool_calls', 0)}\n")
        logf.write(json.dumps({"context_summary": {
            "tick": t,
            "survivors": len(state.get('survivors', [])),
            "fires": len(state.get('fires', [])),
            "commands": len(cmds)
        }, "plan": plan})[:1000] + "\n")
        
        transcript.append(f"t={t}: survivors={len(state.get('survivors', []))}, fires={len(state.get('fires', []))}")
        
        model.step()
        
        # Progress indicator
        if t % 50 == 0 and not render:
            survivors_remaining = len([a for a in model.schedule.agents if hasattr(a, 'life_deadline')])
            print(f"Tick {t}: {survivors_remaining} survivors, {model.rescued} rescued, {model.deaths} deaths")
        
        if not model.running:
            print(f"Simulation ended at tick {t}")
            break
    
    logf.close()
    
    final_metrics = {
        "rescued": model.rescued,
        "deaths": model.deaths,
        "avg_rescue_time": model.avg_rescue_time,
        "fires_extinguished": model.fires_extinguished,
        "roads_cleared": model.roads_cleared,
        "energy_used": model.energy_used,
        "tool_calls": model.tool_calls,
        "invalid_json": model.invalid_json,
        "replans": model.replans,
        "hospital_overflow_events": model.hospital_overflow_events,
        "pathfinding_calls": getattr(model, 'pathfinding_calls', 0),
        "resource_assessments": getattr(model, 'resource_assessments', 0)
    }
    
    print(f"Final results: {model.rescued} rescued, {model.deaths} deaths, {model.tool_calls} tool calls")
    return final_metrics

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--map", type=str, default="configs/map_small.yaml")
    ap.add_argument("--provider", type=str, default="ollama", choices=["ollama","mock","groq","gemini"])
    ap.add_argument("--strategy", type=str, default="react")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--ticks", type=int, default=200)
    ap.add_argument("--render", action="store_true")
    args = ap.parse_args()
    
    m = run_episode(args.map, seed=args.seed, ticks=args.ticks, provider=args.provider, 
                   strategy=args.strategy, render=args.render)
    print("\nFinal Metrics:")
    print(json.dumps(m, indent=2))

if __name__ == "__main__":
    main()
