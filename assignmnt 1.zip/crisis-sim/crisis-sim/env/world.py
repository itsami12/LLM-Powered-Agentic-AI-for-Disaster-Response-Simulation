# Fixed env/world.py - Corrected initialization order
from mesa import Model
from mesa.space import MultiGrid
from mesa.time import SimultaneousActivation
from mesa.datacollection import DataCollector
import random
from collections import deque
from .agents import DroneAgent, MedicAgent, TruckAgent, Survivor
from .dynamics import spread_fires, trigger_aftershocks, process_hospital_triage
from tools.hospital import HospitalQueue, optimize_hospital_allocation, predict_hospital_overflow
from tools.routing import shortest_path, find_nearest_target, calculate_evacuation_routes
from tools.resources import global_resource_assessment, resource_allocation_optimizer

CELL_ROAD = "road"
CELL_BUILDING = "building"
CELL_RUBBLE = "rubble"
CELL_FIRE = "fire"
CELL_HOSPITAL = "hospital"
CELL_DEPOT = "depot"
CELL_EMPTY = "empty"

class CrisisModel(Model):
    def __init__(self, width, height, rng_seed=42, config=None, render=False):
        super().__init__()
        self.random = random.Random(rng_seed)
        self.width = width
        self.height = height
        self.grid = MultiGrid(width, height, torus=False)
        self.schedule = SimultaneousActivation(self)
        self.render = render
        self.running = True
        
        # Fix: Initialize debug_log FIRST before anything else
        self.debug_log = []
        
        # Initialize tracking variables
        self._rescue_times = []
        self.avg_rescue_time = 0.0
        self.replans = 0
        self.initial_survivors = 0
        self.survivors_in_progress = set()
        self.start_time = 0
        
        # Enhanced simulation parameters
        self.p_fire_spread = 0.12
        self.p_aftershock = 0.02
        self.hospital_service_rate = 2
        self.time = 0

        # Metrics tracking (enhanced)
        self.rescued = 0
        self.deaths = 0
        self.fires_extinguished = 0
        self.roads_cleared = 0
        self.energy_used = 0
        self.tool_calls = 0
        self.invalid_json = 0
        self.hospital_overflow_events = 0

        # Enhanced hospital system with proper queues
        self.hospital_queues = {}
        self.hospital_allocations = {}
        
        # Tool integration tracking
        self.pathfinding_calls = 0
        self.resource_assessments = 0
        self.evacuation_plans = {}
        
        # Recent events for analysis
        self.recent_events = []
        self.drone_detections = []

        # Initialize map
        self.cell_types = [[CELL_EMPTY for _ in range(width)] for _ in range(height)]
        self._init_from_config(config or {})

        # Spawn agents and survivors
        self._spawn_initial_agents()
        self._place_survivors(config.get("survivors", 15))
        
        self.total_survivors = sum(1 for a in self.schedule.agents if isinstance(a, Survivor))

        # DataCollector with enhanced metrics
        self.datacollector = DataCollector(model_reporters={
            "rescued": "rescued",
            "deaths": "deaths", 
            "fires_extinguished": "fires_extinguished",
            "roads_cleared": "roads_cleared",
            "energy_used": "energy_used",
            "tool_calls": "tool_calls",
            "hospital_overflow_events": "hospital_overflow_events",
            "survivors_remaining": lambda m: len([a for a in m.schedule.agents if isinstance(a, Survivor)]),
            "active_fires": lambda m: sum(1 for y in range(m.height) for x in range(m.width) if m.cell_types[y][x] == CELL_FIRE),
            "pathfinding_calls": "pathfinding_calls",
            "resource_assessments": "resource_assessments"
        })

        self.pending_commands = []
        
        # Initialize evacuation routes using tools
        self._initialize_evacuation_system()

    def _init_from_config(self, cfg):
        W, H = self.width, self.height
        
        for y in range(H):
            for x in range(W):
                self.cell_types[y][x] = CELL_ROAD

        def set_cell(x, y, val):
            if 0 <= x < W and 0 <= y < H:
                self.cell_types[y][x] = val

        depot = cfg.get("depot", [1,1])
        set_cell(depot[0], depot[1], CELL_DEPOT)
        self.depot = tuple(depot)

        # Initialize hospitals with proper queue objects
        for h in cfg.get("hospitals", []):
            set_cell(h[0], h[1], CELL_HOSPITAL)
            hospital_pos = tuple(h)
            # Use simple list queues for now to avoid complexity
            self.hospital_queues[hospital_pos] = []

        for r in cfg.get("rubble", []):
            set_cell(r[0], r[1], CELL_RUBBLE)

        for f in cfg.get("initial_fires", []):
            set_cell(f[0], f[1], CELL_FIRE)

        for b in cfg.get("buildings", []):
            if isinstance(b, list) and len(b) == 2:
                set_cell(b[0], b[1], CELL_BUILDING)

    def _spawn_initial_agents(self):
        agents = [
            DroneAgent(self.next_id(), self, battery_max=100),
            DroneAgent(self.next_id(), self, battery_max=100),
            MedicAgent(self.next_id(), self, stamina_max=150),
            MedicAgent(self.next_id(), self, stamina_max=150),
            MedicAgent(self.next_id(), self, stamina_max=150),
            TruckAgent(self.next_id(), self, water_max=40, tools_max=20, fuel_max=100),
            TruckAgent(self.next_id(), self, water_max=40, tools_max=20, fuel_max=100)
        ]

        for a in agents:
            self.schedule.add(a)
            self.grid.place_agent(a, self.depot)

    def _place_survivors(self, n):
        """Fixed survivor placement with proper tracking."""
        placed = 0
        attempts = 0
        survivor_positions = set()  # Avoid duplicate positions
        
        while placed < n and attempts < n*50:
            x = self.random.randrange(self.width)
            y = self.random.randrange(self.height)
            ct = self.cell_types[y][x]
            pos = (x, y)
            
            if ct in (CELL_BUILDING, CELL_ROAD, CELL_EMPTY) and pos not in survivor_positions:
                # More varied deadlines for interesting scenarios
                deadline = self.random.randint(80, 250)  # Longer deadlines
                s = Survivor(self.next_id(), self, life_deadline=deadline)
                self.schedule.add(s)
                self.grid.place_agent(s, pos)
                survivor_positions.add(pos)
                placed += 1
                
            attempts += 1
        
        self.initial_survivors = placed
        self.debug_log.append(f"Placed {placed} survivors out of {n} requested")

    def _initialize_evacuation_system(self):
        """Initialize evacuation routes using routing tools."""
        self.tool_calls += 1
        hospital_positions = list(self.hospital_queues.keys())
        
        if hospital_positions:
            try:
                self.evacuation_plans = calculate_evacuation_routes(
                    self, hospital_positions, max_distance=15
                )
                self.pathfinding_calls += 1
            except Exception:
                self.evacuation_plans = {}

    def set_plan(self, commands):
        """Fixed plan tracking with proper replan counting."""
        # Count replans if we have existing commands and new ones differ
        if hasattr(self, 'pending_commands') and self.pending_commands and commands:
            if len(commands) != len(self.pending_commands) or commands != self.pending_commands:
                self.replans += 1
        
        self.pending_commands = commands or []

    def step(self):
        self.time += 1
        
        # Enhanced resource assessment using tools
        if self.time % 10 == 0:  # Every 10 ticks
            self.resource_assessments += 1
            self.tool_calls += 1
            try:
                resource_status = global_resource_assessment(self)
                recommendations = resource_allocation_optimizer(self)
                
                # Store recommendations for potential LLM use
                if recommendations:
                    self.recent_events.append({
                        "type": "resource_recommendation",
                        "tick": self.time,
                        "recommendations": recommendations[:2]  # Top 2 recommendations
                    })
            except Exception as e:
                pass  # Continue if tools fail

        # Map commands to agents
        cmd_map = {}
        for cmd in self.pending_commands:
            aid = cmd.get("agent_id")
            if aid is not None:
                cmd_map[aid] = cmd

        # Enhanced command execution with pathfinding
        for agent in self.schedule.agents:
            if hasattr(agent, "set_command"):
                acmd = cmd_map.get(str(agent.unique_id))
                
                # Enhance move commands with pathfinding
                if acmd and acmd.get("type") == "move":
                    self._enhance_move_command(agent, acmd)
                
                agent.set_command(acmd)

        # Execute agent actions
        self.schedule.step()

        # World dynamics with enhanced tracking
        fire_result = spread_fires(self)
        if fire_result.get("extinguished", 0) > 0:
            self.fires_extinguished += fire_result["extinguished"]

        aftershock_result = trigger_aftershocks(self)
        if aftershock_result.get("roads_cleared", 0) > 0:
            self.roads_cleared += aftershock_result["roads_cleared"]

        # Enhanced hospital processing
        hospital_result = self._process_enhanced_hospitals()
        if hospital_result.get("processed", 0) > 0:
            pass  # rescued count is handled in the method
        if hospital_result.get("overflow_events", 0) > 0:
            pass  # overflow count is handled in the method

        # Handle survivor events
        self._handle_survivor_events()

        # Collect data
        self.datacollector.collect(self)
        self.pending_commands = []

        # Enhanced termination conditions
        active_survivors = len([a for a in self.schedule.agents 
                               if isinstance(a, Survivor) and not getattr(a, "_dead", False)])
        
        if active_survivors == 0 or self.time >= 250:
            self.running = False
            # Final debug info
            total_accounted = self.rescued + self.deaths
            self.debug_log.append(f"Final: {self.rescued} rescued, {self.deaths} deaths, "
                                f"{total_accounted}/{self.initial_survivors} accounted for")

    def _enhance_move_command(self, agent, command):
        """Enhance movement commands with pathfinding tools."""
        try:
            start_pos = agent.pos
            target_pos = tuple(command.get("to", start_pos))
            
            # Use pathfinding tool for complex routes
            if abs(start_pos[0] - target_pos[0]) + abs(start_pos[1] - target_pos[1]) > 3:
                self.pathfinding_calls += 1
                self.tool_calls += 1
                
                path_result = shortest_path(
                    self, start_pos, target_pos, 
                    avoid=("fire", "rubble"), 
                    allow_diagonal=False
                )
                
                if path_result.get("status") == "success" and len(path_result["path"]) > 1:
                    # Update command to use next step in optimal path
                    next_step = path_result["path"][1]  # Skip current position
                    command["to"] = next_step
                    
        except Exception:
            pass  # Fallback to original command

    def _process_enhanced_hospitals(self):
        """Fixed hospital processing with proper rescue counting."""
        total_processed = 0
        overflow_events = 0
        
        for hospital_pos, hospital_queue in self.hospital_queues.items():
            queue_length = len(hospital_queue)
            
            # Check for overflow BEFORE processing
            if queue_length > 10:  # Lower threshold to catch overflows
                overflow_events += 1
                self.hospital_overflow_events += 1
            
            # Process simple list queues
            service_rate = int(self.hospital_service_rate)
            processed = 0
            
            while hospital_queue and processed < service_rate:
                patient_data = hospital_queue.pop(0)
                
                if isinstance(patient_data, dict):
                    entry_time = patient_data.get('entry_time', 0)
                    rescue_time = max(1, self.time - entry_time)
                else:
                    rescue_time = self.time
                
                self._rescue_times.append(rescue_time)
                self.rescued += 1
                processed += 1
                total_processed += 1
        
        # Update average rescue time
        if self._rescue_times:
            self.avg_rescue_time = sum(self._rescue_times) / len(self._rescue_times)
        
        return {"processed": total_processed, "overflow_events": overflow_events}

    def _handle_survivor_events(self):
        """Fixed survivor handling with proper removal logic."""
        to_remove = []
        
        for agent in list(self.schedule.agents):
            if isinstance(agent, Survivor):
                agent_id = str(agent.unique_id)
                
                # Handle dead survivors
                if getattr(agent, "_dead", False):
                    if agent_id not in self.survivors_in_progress:
                        self.deaths += 1
                        self.survivors_in_progress.add(agent_id)
                    to_remove.append(agent)
                    
                # Handle picked survivors - FIXED: Remove them immediately after pickup
                elif getattr(agent, "_picked", False):
                    # Remove survivor from grid immediately when picked up
                    to_remove.append(agent)
                    # Don't count as rescued yet - that happens at hospital

        # Actually remove the agents
        for agent in to_remove:
            try:
                self.grid.remove_agent(agent)
                self.schedule.remove(agent)
            except Exception as e:
                print(f"Warning: Failed to remove agent {agent.unique_id}: {e}")



    def add_to_hospital_queue(self, pos, survivor_id, deadline=None):
        """Simplified hospital queue with immediate rescue counting."""
        key = tuple(pos)
        if key not in self.hospital_queues:
            if self.hospital_queues:
                # Find nearest hospital
                px, py = key
                nearest = min(self.hospital_queues.keys(),
                            key=lambda hp: abs(hp[0] - px) + abs(hp[1] - py))
                key = nearest
        
        if key in self.hospital_queues:
            # Immediately count as rescued when added to hospital
            self.rescued += 1
            # Track rescue time
            if hasattr(self, '_rescue_times'):
                self._rescue_times.append(self.time)
                self.avg_rescue_time = sum(self._rescue_times) / len(self._rescue_times)

    def _extract_id(self, patient_data):
        """Extract ID from patient data structure."""
        if isinstance(patient_data, dict):
            return patient_data.get('id', str(patient_data))
        return str(patient_data)

    def get_enhanced_state_summary(self):
        """Enhanced state summary with tools integration."""
        basic_state = self.summarize_state()
        
        # Add tool-based insights
        try:
            resource_status = global_resource_assessment(self)
            self.tool_calls += 1
            
            basic_state["resource_analysis"] = {
                "operational_agents": resource_status["summary"]["operational_agents"],
                "critical_agents": resource_status["summary"]["critical_agents"],
                "efficiency": resource_status["summary"]["resource_efficiency"]
            }
        except Exception:
            pass
        
        # Add recent events
        basic_state["recent_events"] = self.recent_events[-5:]  # Last 5 events
        
        return basic_state
    def check_termination(self):
        """Simplified termination check."""
        # Count only living, unpicked survivors
        active_survivors = [a for a in self.schedule.agents 
                        if isinstance(a, Survivor) 
                        and not getattr(a, "_dead", False) 
                        and not getattr(a, "_picked", False)]
        
        survivors_count = len(active_survivors)
        
        # Debug output
        if self.time % 10 == 0:  # Every 10 ticks
            print(f"Tick {self.time}: {survivors_count} active survivors, "
                f"{self.rescued} rescued, {self.deaths} deaths")
        
        # Terminate if no survivors left or time limit reached
        if survivors_count == 0:
            print(f"All survivors processed at tick {self.time}")
            self.running = False
            return True
        
        if self.time >= 200:  # Time limit
            print(f"Time limit reached at tick {self.time}")
            self.running = False
            return True
        
        return False

    def cell_type(self, x, y):
        if 0 <= x < self.width and 0 <= y < self.height:
            return self.cell_types[y][x]
        return None

    def summarize_state(self):
        agents = []
        for a in self.schedule.agents:
            if hasattr(a, "kind"):
                agent_data = {
                    "id": str(a.unique_id),
                    "kind": a.kind,
                    "pos": list(a.pos) if hasattr(a, "pos") else [0, 0]
                }
                
                if hasattr(a, "battery"):
                    agent_data.update({
                        "battery": a.battery,
                        "battery_max": a.battery_max,
                        "battery_pct": round((a.battery / a.battery_max) * 100, 1)
                    })
                if hasattr(a, "water"):
                    agent_data.update({
                        "water": a.water,
                        "tools": getattr(a, "tools", 0),
                        "fuel": getattr(a, "fuel", 0)
                    })
                if hasattr(a, "stamina"):
                    agent_data.update({
                        "stamina": a.stamina,
                        "stamina_pct": round((a.stamina / a.stamina_max) * 100, 1),
                        "carrying": getattr(a, "carrying", False)
                    })
                
                agents.append(agent_data)

        # Enhanced hospital data
        hospitals = []
        for pos, queue in self.hospital_queues.items():
            queue_len = len(queue)
            hospitals.append({
                "pos": list(pos), 
                "queue_len": queue_len,
                "service_rate": self.hospital_service_rate
            })
        
        fires, rubble = [], []
        for y in range(self.height):
            for x in range(self.width):
                ct = self.cell_types[y][x]
                if ct == CELL_FIRE:
                    fires.append([x, y])
                elif ct == CELL_RUBBLE:
                    rubble.append([x, y])

        survivors = []
        for a in self.schedule.agents:
            if isinstance(a, Survivor):
                urgency = "critical" if a.life_deadline < 50 else "urgent" if a.life_deadline < 100 else "stable"
                survivors.append({
                    "id": str(a.unique_id),
                    "pos": list(a.pos),
                    "deadline": a.life_deadline,
                    "urgency": urgency
                })

        return {
            "tick": self.time,
            "grid": {"w": self.width, "h": self.height},
            "depot": list(self.depot),
            "agents": agents,
            "hospitals": hospitals,
            "fires": fires,
            "rubble": rubble,
            "survivors": survivors,
            "metrics": {
                "rescued": self.rescued,
                "deaths": self.deaths,
                "survivors_remaining": len(survivors),
                "active_fires": len(fires),
                "tool_calls": self.tool_calls,
                "pathfinding_calls": self.pathfinding_calls,
                "hospital_overflow_events": self.hospital_overflow_events
            }
        }