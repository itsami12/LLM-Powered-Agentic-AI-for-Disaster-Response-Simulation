import random

def spread_fires(model):
    """Fire spreading with controlled rate."""
    W, H = model.width, model.height
    new_fires = []
    extinguished = 0
    
    for y in range(H):
        for x in range(W):
            if model.cell_types[y][x] == "fire":
                # Small chance for natural extinguishing
                if random.random() < 0.02:
                    model.cell_types[y][x] = "road"
                    extinguished += 1
                    continue
                
                # Spread to adjacent cells
                for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < W and 0 <= ny < H:
                        ct = model.cell_types[ny][nx]
                        
                        spread_chance = 0
                        if ct == "building":
                            spread_chance = model.p_fire_spread * 1.2
                        elif ct in ("road", "empty"):
                            spread_chance = model.p_fire_spread * 0.3
                        
                        if spread_chance > 0 and random.random() < spread_chance:
                            new_fires.append((nx, ny))
    
    # Apply new fires
    for (x, y) in new_fires:
        model.cell_types[y][x] = "fire"
    
    return {"extinguished": extinguished, "new_fires": len(new_fires)}

def trigger_aftershocks(model):
    """Aftershock system with reduced impact."""
    if random.random() > model.p_aftershock:
        return {"roads_cleared": 0, "new_rubble": 0}
    
    W, H = model.width, model.height
    new_rubble = 0
    
    # Create limited rubble
    for _ in range(random.randint(1, 2)):
        x = random.randrange(W)
        y = random.randrange(H)
        current_type = model.cell_types[y][x]
        
        if current_type in ("road", "building") and random.random() < 0.3:
            model.cell_types[y][x] = "rubble"
            new_rubble += 1
    
    return {"roads_cleared": 0, "new_rubble": new_rubble}

def process_hospital_triage(model):
    """Process hospital queues efficiently."""
    total_processed = 0
    overflow_events = 0
    
    for hospital_pos, queue in model.hospital_queues.items():
        if not queue:
            continue
        
        # Process survivors
        service_rate = int(model.hospital_service_rate)
        processed = 0
        
        while queue and processed < service_rate:
            survivor_id = queue.pop(0)
            processed += 1
            total_processed += 1
            
            # Track rescue time
            if hasattr(model, '_rescue_times'):
                model._rescue_times.append(model.time)
                model.avg_rescue_time = sum(model._rescue_times) / len(model._rescue_times)
        
        # Check for overflow
        if len(queue) > 12:
            overflow_events += 1
    
    return {"processed": total_processed, "overflow_events": overflow_events}
