# env/sensors.py (enhanced sensor system)
import random
import json

def scan_with_noise(model, center, radius=1, fp=0.1, fn=0.1):
    """
    Scan area around center with configurable false positive/negative rates.
    """
    cx, cy = center
    detections = {"fires": [], "survivors": [], "rubble": [], "agents": []}
    W, H = model.width, model.height
    
    # Scan for fires with noise
    for dy in range(-radius, radius + 1):
        for dx in range(-radius, radius + 1):
            x, y = cx + dx, cy + dy
            if 0 <= x < W and 0 <= y < H:
                is_fire = (model.cell_types[y][x] == "fire")
                if is_fire and random.random() > fn:  # True positive
                    detections["fires"].append([x, y])
                elif (not is_fire) and random.random() < fp:  # False positive
                    detections["fires"].append([x, y])
                
                # Detect rubble
                is_rubble = (model.cell_types[y][x] == "rubble")
                if is_rubble and random.random() > fn:
                    detections["rubble"].append([x, y])
    
    # Scan for survivors (agents with life_deadline attribute)
    for a in model.schedule.agents:
        if hasattr(a, "pos") and hasattr(a, "life_deadline"):
            ax, ay = a.pos
            if abs(ax - cx) <= radius and abs(ay - cy) <= radius:
                if random.random() > fn:  # True positive detection
                    detections["survivors"].append({
                        "pos": [ax, ay],
                        "id": str(a.unique_id),
                        "deadline": getattr(a, "life_deadline", 999),
                        "urgency": "critical" if a.life_deadline < 50 else "moderate" if a.life_deadline < 100 else "stable"
                    })
    
    # Scan for other agents
    for a in model.schedule.agents:
        if hasattr(a, "pos") and not hasattr(a, "life_deadline"):  # Non-survivor agents
            ax, ay = a.pos
            if abs(ax - cx) <= radius and abs(ay - cy) <= radius:
                if random.random() > fn:
                    detections["agents"].append({
                        "pos": [ax, ay],
                        "id": str(a.unique_id),
                        "kind": getattr(a, "kind", "unknown"),
                        "status": _get_agent_status(a)
                    })
    
    return detections

def _get_agent_status(agent):
    """Extract relevant status information from an agent."""
    status = {}
    
    # Battery status for drones
    if hasattr(agent, "battery"):
        battery_pct = (agent.battery / agent.battery_max) * 100 if agent.battery_max > 0 else 0
        status["battery_pct"] = round(battery_pct, 1)
        status["battery_level"] = "critical" if battery_pct < 20 else "low" if battery_pct < 50 else "good"
    
    # Resource status for trucks
    if hasattr(agent, "water"):
        status["water"] = agent.water
        status["tools"] = getattr(agent, "tools", 0)
        status["fuel"] = getattr(agent, "fuel", 0)
    
    # Carrying status for medics
    if hasattr(agent, "carrying"):
        status["carrying"] = agent.carrying
        if hasattr(agent, "stamina"):
            status["stamina"] = agent.stamina
    
    return status

def global_situation_report(model):
    """
    Generate a comprehensive situation report for the crisis.
    """
    report = {
        "tick": getattr(model, "time", 0),
        "overview": {
            "survivors_remaining": len([a for a in model.schedule.agents if hasattr(a, "life_deadline")]),
            "active_fires": sum(1 for y in range(model.height) for x in range(model.width) if model.cell_types[y][x] == "fire"),
            "blocked_roads": sum(1 for y in range(model.height) for x in range(model.width) if model.cell_types[y][x] == "rubble"),
            "hospital_queues": sum(len(q) for q in model.hospital_queues.values()),
            "total_rescued": model.rescued,
            "total_deaths": model.deaths
        },
        "critical_areas": _identify_critical_areas(model),
        "resource_status": _assess_resource_status(model),
        "threats": _assess_threats(model),
        "recommendations": _generate_recommendations(model)
    }
    
    return report

def _identify_critical_areas(model):
    """Identify areas requiring immediate attention."""
    critical_areas = []
    
    # Areas with multiple survivors and nearby fires
    survivor_positions = {}
    for a in model.schedule.agents:
        if hasattr(a, "life_deadline"):
            pos = a.pos
            if pos not in survivor_positions:
                survivor_positions[pos] = []
            survivor_positions[pos].append({
                "id": str(a.unique_id),
                "deadline": a.life_deadline
            })
    
    for pos, survivors in survivor_positions.items():
        if len(survivors) > 1:  # Multiple survivors at same location
            # Check for nearby fires
            nearby_fires = 0
            x, y = pos
            for dx in range(-2, 3):
                for dy in range(-2, 3):
                    nx, ny = x + dx, y + dy
                    if (0 <= nx < model.width and 0 <= ny < model.height and 
                        model.cell_types[ny][nx] == "fire"):
                        nearby_fires += 1
            
            if nearby_fires > 0:
                critical_areas.append({
                    "pos": list(pos),
                    "reason": "multiple_survivors_near_fire",
                    "survivor_count": len(survivors),
                    "nearby_fires": nearby_fires,
                    "most_urgent_deadline": min(s["deadline"] for s in survivors)
                })
    
    return critical_areas

def _assess_resource_status(model):
    """Assess current resource availability across all agents."""
    resources = {
        "drones": {"count": 0, "avg_battery": 0, "low_battery": 0},
        "medics": {"count": 0, "carrying": 0, "low_stamina": 0},
        "trucks": {"count": 0, "avg_water": 0, "avg_tools": 0, "low_fuel": 0}
    }
    
    drone_batteries, truck_water, truck_tools = [], [], []
    
    for a in model.schedule.agents:
        if hasattr(a, "kind"):
            if a.kind == "drone":
                resources["drones"]["count"] += 1
                if hasattr(a, "battery"):
                    drone_batteries.append(a.battery)
                    if a.battery < 20:
                        resources["drones"]["low_battery"] += 1
            
            elif a.kind == "medic":
                resources["medics"]["count"] += 1
                if hasattr(a, "carrying") and a.carrying:
                    resources["medics"]["carrying"] += 1
                if hasattr(a, "stamina") and a.stamina < 30:
                    resources["medics"]["low_stamina"] += 1
            
            elif a.kind == "truck":
                resources["trucks"]["count"] += 1
                if hasattr(a, "water"):
                    truck_water.append(a.water)
                if hasattr(a, "tools"):
                    truck_tools.append(a.tools)
                if hasattr(a, "fuel") and a.fuel < 10:
                    resources["trucks"]["low_fuel"] += 1
    
    # Calculate averages
    if drone_batteries:
        resources["drones"]["avg_battery"] = round(sum(drone_batteries) / len(drone_batteries), 1)
    if truck_water:
        resources["trucks"]["avg_water"] = round(sum(truck_water) / len(truck_water), 1)
    if truck_tools:
        resources["trucks"]["avg_tools"] = round(sum(truck_tools) / len(truck_tools), 1)
    
    return resources

def _assess_threats(model):
    """Assess current and projected threats."""
    threats = []
    
    # Fire spread threat
    fire_cells = [(x, y) for y in range(model.height) for x in range(model.width) 
                  if model.cell_types[y][x] == "fire"]
    
    if len(fire_cells) > 5:
        threats.append({
            "type": "widespread_fire",
            "severity": "high",
            "description": f"{len(fire_cells)} active fire cells detected",
            "projected_impact": "Fire spread may trap survivors and damage infrastructure"
        })
    
    # Survivor deadline threat
    critical_survivors = 0
    for a in model.schedule.agents:
        if hasattr(a, "life_deadline") and a.life_deadline < 30:
            critical_survivors += 1
    
    if critical_survivors > 0:
        threats.append({
            "type": "survivor_deadline",
            "severity": "critical",
            "description": f"{critical_survivors} survivors have less than 30 ticks remaining",
            "projected_impact": "Imminent survivor casualties without immediate intervention"
        })
    
    # Hospital overflow threat
    total_queue_length = sum(len(q) for q in model.hospital_queues.values())
    if total_queue_length > 10:
        threats.append({
            "type": "hospital_overflow",
            "severity": "moderate",
            "description": f"{total_queue_length} survivors waiting for hospital treatment",
            "projected_impact": "Delayed treatment may result in preventable casualties"
        })
    
    return threats

def _generate_recommendations(model):
    """Generate tactical recommendations based on current situation."""
    recommendations = []
    
    # Check if we need more fire suppression
    fire_count = sum(1 for y in range(model.height) for x in range(model.width) 
                    if model.cell_types[y][x] == "fire")
    truck_count = len([a for a in model.schedule.agents 
                      if hasattr(a, "kind") and a.kind == "truck"])
    
    if fire_count > truck_count * 3:
        recommendations.append({
            "priority": "high",
            "action": "Focus trucks on fire suppression",
            "rationale": f"{fire_count} fires detected, but only {truck_count} trucks available"
        })
    
    # Check medic efficiency
    survivor_count = len([a for a in model.schedule.agents if hasattr(a, "life_deadline")])
    medic_count = len([a for a in model.schedule.agents 
                      if hasattr(a, "kind") and a.kind == "medic"])
    
    if survivor_count > medic_count * 5:
        recommendations.append({
            "priority": "high", 
            "action": "Optimize medic routes and prioritize critical cases",
            "rationale": f"{survivor_count} survivors need rescue, {medic_count} medics available"
        })
    
    # Resource management
    low_battery_drones = len([a for a in model.schedule.agents 
                             if (hasattr(a, "kind") and a.kind == "drone" and 
                                 hasattr(a, "battery") and a.battery < 20)])
    if low_battery_drones > 0:
        recommendations.append({
            "priority": "medium",
            "action": "Send drones to depot for battery recharge",
            "rationale": f"{low_battery_drones} drones have critically low battery"
        })
    
    return recommendations

def export_situation_for_llm(model, max_detail_radius=5):
    """
    Export a token-efficient situation summary for LLM consumption.
    Focuses on most critical information within a reasonable detail radius.
    """
    # Basic grid info
    situation = {
        "grid": {"width": model.width, "height": model.height},
        "tick": getattr(model, "time", 0),
        "depot": getattr(model, "depot", [1, 1])
    }
    
    # Critical locations
    situation["hospitals"] = [{"pos": list(pos), "queue": len(q)} 
                             for pos, q in model.hospital_queues.items()]
    
    # Immediate threats (fires and rubble)
    situation["fires"] = [[x, y] for y in range(model.height) for x in range(model.width) 
                         if model.cell_types[y][x] == "fire"]
    situation["rubble"] = [[x, y] for y in range(model.height) for x in range(model.width) 
                          if model.cell_types[y][x] == "rubble"]
    
    # Agents with essential info only
    agents = []
    for a in model.schedule.agents:
        if not hasattr(a, "pos"):
            continue
            
        agent_info = {
            "id": str(a.unique_id),
            "pos": list(a.pos),
            "kind": getattr(a, "kind", "unknown")
        }
        
        # Add critical status info
        if hasattr(a, "battery"):
            agent_info["battery"] = f"{a.battery}/{a.battery_max}"
        if hasattr(a, "water"):
            agent_info["resources"] = f"W:{a.water} T:{getattr(a, 'tools', 0)} F:{getattr(a, 'fuel', 0)}"
        if hasattr(a, "carrying"):
            agent_info["carrying"] = a.carrying
        if hasattr(a, "life_deadline"):
            agent_info["deadline"] = a.life_deadline
            agent_info["urgency"] = ("critical" if a.life_deadline < 30 else 
                                   "urgent" if a.life_deadline < 60 else "stable")
        
        agents.append(agent_info)
    
    situation["agents"] = agents
    
    # High-level metrics
    situation["metrics"] = {
        "rescued": model.rescued,
        "deaths": model.deaths,
        "fires_active": len(situation["fires"]),
        "survivors_remaining": len([a for a in agents if "deadline" in a])
    }
    
    return situation