# Fixed env/agents.py
from mesa import Agent

class BaseAgent(Agent):
    def __init__(self, unique_id, model):
        super().__init__(unique_id, model)
        self.command = None

    def set_command(self, cmd):
        self.command = cmd

    def step(self):
        if not self.command:
            return
            
        if self.command.get("type") == "move":
            to = tuple(self.command.get("to", self.pos))
            if not self.model.grid.out_of_bounds(to):
                if not self._is_movement_blocked(to):
                    self.model.grid.move_agent(self, to)
                    self._consume_movement_energy()
        elif self.command.get("type") == "act":
            self._do_act(self.command)

    def advance(self):
        pass

    def _do_act(self, cmd):
        pass

    def _is_movement_blocked(self, target):
        x, y = target
        cell_type = self.model.cell_type(x, y)
        return cell_type in ("rubble", "fire")

    def _consume_movement_energy(self):
        pass

class Survivor(Agent):
    def __init__(self, unique_id, model, life_deadline=200):
        super().__init__(unique_id, model)
        self.life_deadline = life_deadline
        self._picked = False
        self._dead = False

    def step(self):
        if not self._picked and not self._dead:
            self.life_deadline -= 1
            if self.life_deadline <= 0:
                self._dead = True

    def advance(self):
        pass

class MedicAgent(BaseAgent):
    kind = "medic"
    
    def __init__(self, unique_id, model, stamina_max=100):
        super().__init__(unique_id, model)
        self.carrying = False
        self.carrying_id = None
        self.stamina_max = stamina_max
        self.stamina = stamina_max

    def _consume_movement_energy(self):
        cost = 3 if self.carrying else 2
        self.stamina = max(0, self.stamina - cost)
        self.model.energy_used += cost

    def step(self):
        if self.stamina <= 5:  # Can't move when very tired
            return
        super().step()
        # Slow stamina regeneration
        self.stamina = min(self.stamina_max, self.stamina + 1)

    def _do_act(self, cmd):
        action = cmd.get("action_name")
        
        if action == "pickup_survivor":
            cell_agents = self.model.grid.get_cell_list_contents([self.pos])
            survivor = next((a for a in cell_agents if isinstance(a, Survivor) and not a._picked), None)
            if survivor and not self.carrying:
                self.carrying = True
                self.carrying_id = survivor.unique_id
                survivor._picked = True

        elif action == "drop_at_hospital":
            x, y = self.pos
            if self.model.cell_type(x, y) == "hospital" and self.carrying:
                self.model.add_to_hospital_queue(self.pos, str(self.carrying_id))
                self.carrying = False
                self.carrying_id = None

        elif action == "recharge_stamina":
            x, y = self.pos
            if self.model.cell_type(x, y) == "depot":
                self.stamina = self.stamina_max

class TruckAgent(BaseAgent):
    kind = "truck"
    
    def __init__(self, unique_id, model, water_max=30, tools_max=10, fuel_max=50):
        super().__init__(unique_id, model)
        self.water_max = water_max
        self.tools_max = tools_max
        self.fuel_max = fuel_max
        self.water = water_max
        self.tools = tools_max
        self.fuel = fuel_max

    def _consume_movement_energy(self):
        if self.fuel > 0:
            self.fuel -= 1
            self.model.energy_used += 1

    def step(self):
        if self.fuel <= 0:
            return
        super().step()

    def _do_act(self, cmd):
        action = cmd.get("action_name")
        x, y = self.pos

        if action == "extinguish" and self.water > 0:
            if self.model.cell_type(x, y) == "fire":
                self.model.cell_types[y][x] = "road"
                self.water -= 1
                self.model.fires_extinguished += 1

        elif action == "clear_rubble" and self.tools > 0:
            # Fix: Ensure rubble clearing actually works
            if self.model.cell_type(x, y) == "rubble":
                self.model.cell_types[y][x] = "road"
                self.tools -= 1
                self.model.roads_cleared += 1
                # Debug log
                if hasattr(self.model, 'debug_log'):
                    self.model.debug_log.append(f"Truck {self.unique_id} cleared rubble at {x},{y}")

        elif action == "refuel":
            if self.model.cell_type(x, y) == "depot":
                self.fuel = self.fuel_max
                self.water = self.water_max
                self.tools = self.tools_max
class DroneAgent(BaseAgent):
    kind = "drone"
    
    def __init__(self, unique_id, model, battery_max=80):
        super().__init__(unique_id, model)
        self.battery_max = battery_max
        self.battery = battery_max

    def _consume_movement_energy(self):
        if self.battery > 0:
            self.battery -= 1
            self.model.energy_used += 1

    def step(self):
        if self.battery <= 0:
            return
        super().step()
        # Passive drain
        self.battery = max(0, self.battery - 1)

    def _do_act(self, cmd):
        action = cmd.get("action_name")
        x, y = self.pos

        if action == "recharge_battery":
            if self.model.cell_type(x, y) == "depot":
                self.battery = self.battery_max

        elif action == "survey_area":
            # Survey functionality
            pass
