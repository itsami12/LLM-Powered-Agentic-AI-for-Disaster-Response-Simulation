# tools/routing.py (enhanced pathfinding utilities)
from heapq import heappush, heappop
import math

def manhattan(a, b):
    """Calculate Manhattan distance between two points."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def euclidean(a, b):
    """Calculate Euclidean distance between two points."""
    return math.sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2)

def shortest_path(model, start, goal, avoid=("fire", "rubble"), allow_diagonal=False):
    """
    A* pathfinding algorithm with configurable avoidance and movement types.
    
    Args:
        model: CrisisModel instance with width, height, cell_types
        start: Starting position (x, y)
        goal: Goal position (x, y)
        avoid: Tuple of cell types to avoid
        allow_diagonal: Whether to allow diagonal movement
    
    Returns:
        Dict with status, path, and cost
    """
    W, H = model.width, model.height
    start, goal = tuple(start), tuple(goal)
    blocked = set(avoid)

    def is_passable(x, y):
        if not (0 <= x < W and 0 <= y < H):
            return False
        cell_type = model.cell_types[y][x]
        return cell_type not in blocked

    # Movement directions
    if allow_diagonal:
        directions = [(1,0), (-1,0), (0,1), (0,-1), (1,1), (1,-1), (-1,1), (-1,-1)]
        move_costs = [1, 1, 1, 1, 1.414, 1.414, 1.414, 1.414]  # Diagonal cost
    else:
        directions = [(1,0), (-1,0), (0,1), (0,-1)]
        move_costs = [1, 1, 1, 1]

    # A* algorithm
    open_set = []
    heappush(open_set, (0 + manhattan(start, goal), 0, start, None))
    came_from = {}
    g_score = {start: 0}
    f_score = {start: manhattan(start, goal)}

    while open_set:
        current_f, current_g, current, parent = heappop(open_set)
        
        if current in came_from:
            continue  # Already processed
        
        came_from[current] = parent
        
        if current == goal:
            # Reconstruct path
            path = []
            node = goal
            while node is not None:
                path.append(list(node))
                node = came_from.get(node)
            path.reverse()
            
            return {
                "status": "success",
                "path": path,
                "cost": g_score[goal],
                "length": len(path)
            }

        x, y = current
        for i, (dx, dy) in enumerate(directions):
            neighbor = (x + dx, y + dy)
            
            if not is_passable(neighbor[0], neighbor[1]):
                continue
            
            tentative_g = g_score[current] + move_costs[i]
            
            if neighbor not in g_score or tentative_g < g_score[neighbor]:
                g_score[neighbor] = tentative_g
                f_score[neighbor] = tentative_g + manhattan(neighbor, goal)
                heappush(open_set, (f_score[neighbor], tentative_g, neighbor, current))

    # No path found
    return {
        "status": "blocked",
        "path": [],
        "cost": None,
        "length": 0
    }

def find_safe_path(model, start, goal, safety_margin=1):
    """
    Find a path that maintains distance from dangerous areas.
    
    Args:
        model: CrisisModel instance
        start: Starting position
        goal: Goal position  
        safety_margin: Minimum distance to maintain from fires
    
    Returns:
        Dict with path information
    """
    W, H = model.width, model.height
    
    def is_safe(x, y):
        if not (0 <= x < W and 0 <= y < H):
            return False
        
        cell_type = model.cell_types[y][x]
        if cell_type in ("fire", "rubble"):
            return False
        
        # Check safety margin around fires
        for dx in range(-safety_margin, safety_margin + 1):
            for dy in range(-safety_margin, safety_margin + 1):
                nx, ny = x + dx, y + dy
                if (0 <= nx < W and 0 <= ny < H and 
                    model.cell_types[ny][nx] == "fire"):
                    return False
        
        return True
    
    # Use modified A* with safety constraints
    start, goal = tuple(start), tuple(goal)
    open_set = []
    heappush(open_set, (0 + manhattan(start, goal), 0, start, None))
    came_from = {}
    g_score = {start: 0}

    while open_set:
        current_f, current_g, current, parent = heappop(open_set)
        
        if current in came_from:
            continue
            
        came_from[current] = parent
        
        if current == goal:
            # Reconstruct path
            path = []
            node = goal
            while node is not None:
                path.append(list(node))
                node = came_from.get(node)
            path.reverse()
            
            return {
                "status": "success",
                "path": path,
                "cost": g_score[goal],
                "safety_level": "high"
            }

        x, y = current
        for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
            neighbor = (x + dx, y + dy)
            
            if not is_safe(neighbor[0], neighbor[1]):
                continue
                
            tentative_g = g_score[current] + 1
            
            if neighbor not in g_score or tentative_g < g_score[neighbor]:
                g_score[neighbor] = tentative_g
                heappush(open_set, (tentative_g + manhattan(neighbor, goal), 
                                  tentative_g, neighbor, current))

    # Fallback to regular pathfinding if safe path not found
    return shortest_path(model, start, goal, avoid=("rubble",))

def find_nearest_target(model, start, target_positions, avoid=("fire", "rubble")):
    """
    Find the nearest reachable target from a list of positions.
    
    Args:
        model: CrisisModel instance
        start: Starting position
        target_positions: List of target positions to evaluate
        avoid: Cell types to avoid in pathfinding
    
    Returns:
        Dict with best target and path information
    """
    best_target = None
    best_path = None
    best_cost = float('inf')
    
    for target in target_positions:
        path_result = shortest_path(model, start, target, avoid=avoid)
        
        if path_result["status"] == "success" and path_result["cost"] < best_cost:
            best_cost = path_result["cost"]
            best_target = target
            best_path = path_result["path"]
    
    if best_target is not None:
        return {
            "status": "success",
            "target": best_target,
            "path": best_path,
            "cost": best_cost
        }
    else:
        return {
            "status": "no_reachable_targets",
            "target": None,
            "path": [],
            "cost": None
        }

def calculate_evacuation_routes(model, hospital_positions, max_distance=15):
    """
    Calculate optimal evacuation routes from all positions to hospitals.
    
    Args:
        model: CrisisModel instance
        hospital_positions: List of hospital positions
        max_distance: Maximum distance to consider for evacuation
    
    Returns:
        Dict mapping positions to best evacuation route
    """
    W, H = model.width, model.height
    evacuation_map = {}
    
    # Pre-calculate routes from strategic positions
    strategic_positions = []
    
    # Add all non-blocked cells as potential evacuation points
    for y in range(H):
        for x in range(W):
            if model.cell_types[y][x] not in ("fire", "rubble"):
                strategic_positions.append((x, y))
    
    for pos in strategic_positions:
        # Find best hospital for this position
        route_result = find_nearest_target(model, pos, hospital_positions, avoid=("fire", "rubble"))
        
        if route_result["status"] == "success" and route_result["cost"] <= max_distance:
            evacuation_map[pos] = {
                "hospital": route_result["target"],
                "path": route_result["path"],
                "distance": route_result["cost"],
                "safety_rating": _calculate_path_safety(model, route_result["path"])
            }
    
    return evacuation_map

def _calculate_path_safety(model, path):
    """Calculate safety rating for a path (0-1, higher is safer)."""
    if not path:
        return 0.0
    
    danger_score = 0
    total_points = len(path)
    
    for x, y in path:
        # Check surrounding area for dangers
        local_danger = 0
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                nx, ny = x + dx, y + dy
                if (0 <= nx < model.width and 0 <= ny < model.height):
                    cell_type = model.cell_types[ny][nx]
                    if cell_type == "fire":
                        local_danger += 3
                    elif cell_type == "rubble":
                        local_danger += 1
        
        danger_score += local_danger
    
    # Normalize to 0-1 scale (lower danger = higher safety)
    max_possible_danger = total_points * 9 * 3  # 9 surrounding cells, max danger 3
    if max_possible_danger == 0:
        return 1.0
    
    safety_rating = 1.0 - min(danger_score / max_possible_danger, 1.0)
    return safety_rating

def get_reachable_area(model, start, max_distance, avoid=("fire", "rubble")):
    """
    Get all positions reachable within a certain distance from start.
    
    Args:
        model: CrisisModel instance
        start: Starting position
        max_distance: Maximum distance to explore
        avoid: Cell types to avoid
    
    Returns:
        Set of reachable positions
    """
    W, H = model.width, model.height
    start = tuple(start)
    blocked = set(avoid)
    
    reachable = set()
    visited = set()
    queue = [(start, 0)]  # (position, distance)
    
    while queue:
        (x, y), distance = queue.pop(0)
        
        if (x, y) in visited or distance > max_distance:
            continue
        
        visited.add((x, y))
        
        # Check if position is passable
        if (0 <= x < W and 0 <= y < H and 
            model.cell_types[y][x] not in blocked):
            reachable.add((x, y))
            
            # Add neighbors to queue
            for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
                neighbor = (x + dx, y + dy)
                if neighbor not in visited:
                    queue.append((neighbor, distance + 1))
    
    return reachable