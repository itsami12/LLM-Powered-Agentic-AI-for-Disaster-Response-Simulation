# tools/hospital.py
import heapq
from collections import deque

class HospitalQueue:
    """Advanced hospital queue with multiple triage policies."""
    
    def __init__(self, capacity=20, policy="priority"):
        self.capacity = capacity
        self.policy = policy  # "fifo", "priority", "deadline"
        self.queue = []
        self.overflow_count = 0
        
    def add_patient(self, survivor_id, deadline=None, severity=None):
        """Add a patient to the queue based on triage policy."""
        if len(self.queue) >= self.capacity:
            self.overflow_count += 1
            return False  # Queue full
        
        patient = {
            "id": str(survivor_id),
            "deadline": deadline or 999,
            "severity": severity or "moderate",
            "arrival_time": len(self.queue)  # Simple timestamp
        }
        
        if self.policy == "fifo":
            self.queue.append(patient)
        elif self.policy == "priority":
            # Priority based on severity
            severity_priority = {"critical": 1, "urgent": 2, "moderate": 3, "stable": 4}
            priority = severity_priority.get(severity, 3)
            heapq.heappush(self.queue, (priority, patient["arrival_time"], patient))
        elif self.policy == "deadline":
            # Priority based on remaining time
            heapq.heappush(self.queue, (deadline or 999, patient["arrival_time"], patient))
        
        return True
    
    def process_patients(self, service_rate=2):
        """Process patients from the queue."""
        processed = []
        
        for _ in range(min(service_rate, len(self.queue))):
            if not self.queue:
                break
                
            if self.policy == "fifo":
                patient = self.queue.pop(0)
            else:
                # Priority queue (heap)
                if self.queue:
                    _, _, patient = heapq.heappop(self.queue)
                else:
                    break
            
            processed.append(patient["id"])
        
        return processed
    
    def get_status(self):
        """Get current queue status."""
        return {
            "length": len(self.queue),
            "capacity": self.capacity,
            "utilization": len(self.queue) / self.capacity,
            "overflow_events": self.overflow_count,
            "policy": self.policy
        }

def hospital_queue_state(model):
    """Get comprehensive hospital queue state."""
    hospital_states = {}
    
    for pos, queue in model.hospital_queues.items():
        # Convert simple list to queue object if needed
        if isinstance(queue, list):
            queue_obj = HospitalQueue(policy="fifo")
            for survivor_id in queue:
                # Try to find deadline from model
                deadline = 999
                for agent in model.schedule.agents:
                    if str(agent.unique_id) == str(survivor_id) and hasattr(agent, 'life_deadline'):
                        deadline = agent.life_deadline
                        break
                queue_obj.add_patient(survivor_id, deadline=deadline)
        else:
            queue_obj = queue
        
        hospital_states[pos] = {
            "position": list(pos),
            "queue_length": len(model.hospital_queues[pos]),
            "service_rate": model.hospital_service_rate,
            "status": queue_obj.get_status() if hasattr(queue_obj, 'get_status') else {"length": len(model.hospital_queues[pos])}
        }
    
    return {
        "hospitals": hospital_states,
        "total_queue_length": sum(len(q) for q in model.hospital_queues.values()),
        "average_wait_time": calculate_average_wait_time(model)
    }

def calculate_average_wait_time(model):
    """Calculate average wait time across all hospital queues."""
    total_wait = 0
    total_patients = 0
    
    for pos, queue in model.hospital_queues.items():
        queue_length = len(queue)
        if queue_length > 0:
            # Estimate wait time based on queue position and service rate
            service_rate = model.hospital_service_rate
            for i, patient_id in enumerate(queue):
                estimated_wait = (i + 1) / service_rate
                total_wait += estimated_wait
                total_patients += 1
    
    return total_wait / total_patients if total_patients > 0 else 0

def optimize_hospital_allocation(model, survivor_positions):
    """
    Determine optimal hospital allocation for survivors based on:
    - Distance to hospitals
    - Current queue lengths
    - Hospital capacity
    """
    allocations = {}
    
    for survivor_pos in survivor_positions:
        best_hospital = None
        best_score = float('inf')
        
        for hospital_pos, queue in model.hospital_queues.items():
            # Calculate distance
            distance = abs(survivor_pos[0] - hospital_pos[0]) + abs(survivor_pos[1] - hospital_pos[1])
            
            # Calculate queue penalty
            queue_length = len(queue)
            queue_penalty = queue_length * 2  # 2 ticks per queued patient
            
            # Calculate total cost (distance + wait time)
            total_cost = distance + queue_penalty
            
            if total_cost < best_score:
                best_score = total_cost
                best_hospital = hospital_pos
        
        if best_hospital:
            allocations[tuple(survivor_pos)] = {
                "hospital": best_hospital,
                "estimated_cost": best_score,
                "distance": abs(survivor_pos[0] - best_hospital[0]) + abs(survivor_pos[1] - best_hospital[1]),
                "queue_length": len(model.hospital_queues[best_hospital])
            }
    
    return allocations

def predict_hospital_overflow(model, time_horizon=20):
    """
    Predict potential hospital overflow events in the near future.
    """
    predictions = {}
    
    for hospital_pos, queue in model.hospital_queues.items():
        current_length = len(queue)
        service_rate = model.hospital_service_rate
        
        # Estimate queue growth (survivors being rescued)
        active_medics = len([a for a in model.schedule.agents 
                           if hasattr(a, 'kind') and a.kind == 'medic'])
        
        # Simple prediction: medics rescue at ~0.5 survivors per tick
        estimated_arrivals = active_medics * 0.5 * time_horizon
        estimated_processed = service_rate * time_horizon
        
        predicted_length = current_length + estimated_arrivals - estimated_processed
        
        predictions[hospital_pos] = {
            "current_length": current_length,
            "predicted_length": max(0, predicted_length),
            "overflow_risk": "high" if predicted_length > 15 else "medium" if predicted_length > 10 else "low",
            "time_to_overflow": max(0, (15 - current_length) / (estimated_arrivals / time_horizon - service_rate)) if estimated_arrivals > service_rate * time_horizon else None
        }
    
    return predictions

def get_hospital_efficiency_metrics(model):
    """Calculate efficiency metrics for hospital operations."""
    total_rescued = model.rescued
    total_time = model.time
    total_queue_time = 0
    
    # Calculate total patient-ticks spent in queues
    for queue in model.hospital_queues.values():
        total_queue_time += len(queue)
    
    # Calculate throughput and utilization metrics
    metrics = {
        "rescue_rate": total_rescued / total_time if total_time > 0 else 0,
        "average_queue_length": total_queue_time / len(model.hospital_queues) if model.hospital_queues else 0,
        "hospital_utilization": sum(len(q) for q in model.hospital_queues.values()) / (len(model.hospital_queues) * 15),  # Assuming capacity of 15
        "overflow_events": model.hospital_overflow_events,
        "service_efficiency": total_rescued / (total_time * len(model.hospital_queues) * model.hospital_service_rate) if total_time > 0 else 0
    }
    
    return metrics