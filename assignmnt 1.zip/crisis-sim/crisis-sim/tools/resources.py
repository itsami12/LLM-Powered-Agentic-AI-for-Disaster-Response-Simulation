# tools/resources.py
def inventory_state(model, agent_id: str):
    """Get detailed inventory state for a specific agent."""
    for agent in model.schedule.agents:
        if str(agent.unique_id) == str(agent_id):
            base_info = {
                "agent_id": str(agent_id),
                "kind": getattr(agent, "kind", "unknown"),
                "position": list(getattr(agent, "pos", [0, 0]))
            }
            
            # Agent-specific resources
            if hasattr(agent, "battery"):
                base_info.update({
                    "battery": agent.battery,
                    "battery_max": agent.battery_max,
                    "battery_pct": round((agent.battery / agent.battery_max) * 100, 1),
                    "battery_status": get_battery_status(agent.battery, agent.battery_max)
                })
            
            if hasattr(agent, "water"):
                base_info.update({
                    "water": agent.water,
                    "water_max": getattr(agent, "water_max", 30),
                    "tools": getattr(agent, "tools", 0),
                    "tools_max": getattr(agent, "tools_max", 10),
                    "fuel": getattr(agent, "fuel", 0),
                    "fuel_max": getattr(agent, "fuel_max", 50)
                })
            
            if hasattr(agent, "stamina"):
                base_info.update({
                    "stamina": agent.stamina,
                    "stamina_max": agent.stamina_max,
                    "stamina_pct": round((agent.stamina / agent.stamina_max) * 100, 1),
                    "carrying": getattr(agent, "carrying", False),
                    "carrying_id": getattr(agent, "carrying_id", None)
                })
            
            # Add operational status
            base_info["operational_status"] = get_operational_status(agent)
            base_info["recommended_action"] = get_recommended_action(agent, model)
            
            return base_info
    
    return {"status": "error", "reason": "agent_not_found"}

def get_battery_status(battery, battery_max):
    """Determine battery status level."""
    pct = (battery / battery_max) * 100
    if pct < 20:
        return "critical"
    elif pct < 40:
        return "low"
    elif pct < 70:
        return "moderate"
    else:
        return "good"

def get_operational_status(agent):
    """Determine overall operational status of an agent."""
    if hasattr(agent, "battery"):
        # Drone status
        if agent.battery <= 0:
            return "inoperative"
        elif agent.battery < 10:
            return "critical"
        elif agent.battery < 25:
            return "limited"
        else:
            return "operational"
    
    elif hasattr(agent, "stamina"):
        # Medic status
        if agent.stamina <= 0:
            return "exhausted"
        elif agent.stamina < 20:
            return "tired"
        else:
            return "operational"
    
    elif hasattr(agent, "fuel"):
        # Truck status
        if agent.fuel <= 0:
            return "stranded"
        elif agent.fuel < 10:
            return "critical"
        elif agent.water <= 0 and agent.tools <= 0:
            return "depleted"
        else:
            return "operational"
    
    return "operational"

def get_recommended_action(agent, model):
    """Get recommended action based on agent status."""
    if hasattr(agent, "battery"):
        # Drone recommendations
        if agent.battery < 20:
            return "return_to_depot_recharge"
        elif agent.battery < 40:
            return "conserve_battery"
        else:
            return "continue_mission"
    
    elif hasattr(agent, "stamina"):
        # Medic recommendations
        if agent.stamina < 20:
            return "rest_at_depot"
        elif agent.carrying:
            return "deliver_to_hospital"
        else:
            return "rescue_survivors"
    
    elif hasattr(agent, "fuel"):
        # Truck recommendations
        if agent.fuel < 10:
            return "refuel_at_depot"
        elif agent.water <= 5 and agent.tools <= 2:
            return "resupply_at_depot"
        elif agent.water > 0 and hasattr(model, 'cell_types'):
            # Check for nearby fires
            x, y = agent.pos
            for dx in range(-2, 3):
                for dy in range(-2, 3):
                    nx, ny = x + dx, y + dy
                    if (0 <= nx < model.width and 0 <= ny < model.height and 
                        model.cell_types[ny][nx] == "fire"):
                        return "extinguish_fires"
            return "clear_rubble"
        else:
            return "resupply_at_depot"
    
    return "continue_mission"

def global_resource_assessment(model):
    """Assess resource state across all agents in the model."""
    assessment = {
        "drones": [],
        "medics": [],
        "trucks": [],
        "summary": {
            "total_agents": 0,
            "operational_agents": 0,
            "critical_agents": 0,
            "resource_efficiency": 0.0
        }
    }
    
    total_agents = 0
    operational_count = 0
    critical_count = 0
    
    for agent in model.schedule.agents:
        if not hasattr(agent, "kind"):
            continue
            
        total_agents += 1
        agent_data = inventory_state(model, agent.unique_id)
        
        # Categorize by agent type
        if agent.kind == "drone":
            assessment["drones"].append(agent_data)
        elif agent.kind == "medic":
            assessment["medics"].append(agent_data)
        elif agent.kind == "truck":
            assessment["trucks"].append(agent_data)
        
        # Count operational status
        status = agent_data.get("operational_status", "operational")
        if status in ["operational", "moderate"]:
            operational_count += 1
        elif status in ["critical", "inoperative", "exhausted", "stranded"]:
            critical_count += 1
    
    # Calculate summary statistics
    assessment["summary"].update({
        "total_agents": total_agents,
        "operational_agents": operational_count,
        "critical_agents": critical_count,
        "operational_percentage": round((operational_count / total_agents) * 100, 1) if total_agents > 0 else 0,
        "resource_efficiency": calculate_resource_efficiency(model)
    })
    
    return assessment

def calculate_resource_efficiency(model):
    """Calculate overall resource utilization efficiency."""
    if not hasattr(model, 'schedule') or not model.schedule.agents:
        return 0.0
    
    efficiency_scores = []
    
    for agent in model.schedule.agents:
        if not hasattr(agent, "kind"):
            continue
        
        agent_efficiency = 1.0  # Base efficiency
        
        # Drone efficiency based on battery usage
        if hasattr(agent, "battery"):
            battery_pct = agent.battery / agent.battery_max
            agent_efficiency = battery_pct  # Higher battery = higher efficiency
        
        # Medic efficiency based on stamina and carrying status
        elif hasattr(agent, "stamina"):
            stamina_pct = agent.stamina / agent.stamina_max
            carrying_bonus = 1.2 if getattr(agent, "carrying", False) else 1.0
            agent_efficiency = stamina_pct * carrying_bonus
        
        # Truck efficiency based on resource availability
        elif hasattr(agent, "fuel"):
            fuel_pct = agent.fuel / getattr(agent, "fuel_max", 50)
            resource_availability = (
                (agent.water / getattr(agent, "water_max", 30)) +
                (getattr(agent, "tools", 0) / getattr(agent, "tools_max", 10))
            ) / 2
            agent_efficiency = (fuel_pct + resource_availability) / 2
        
        efficiency_scores.append(max(0.0, min(1.0, agent_efficiency)))
    
    return round(sum(efficiency_scores) / len(efficiency_scores), 3) if efficiency_scores else 0.0

def resource_allocation_optimizer(model):
    """Optimize resource allocation based on current needs."""
    recommendations = []
    
    # Assess current situation
    fires = sum(1 for y in range(model.height) for x in range(model.width) 
               if model.cell_types[y][x] == "fire")
    rubble = sum(1 for y in range(model.height) for x in range(model.width) 
                if model.cell_types[y][x] == "rubble")
    survivors = len([a for a in model.schedule.agents if hasattr(a, "life_deadline")])
    
    # Get agent counts and status
    drones = [a for a in model.schedule.agents if hasattr(a, "kind") and a.kind == "drone"]
    medics = [a for a in model.schedule.agents if hasattr(a, "kind") and a.kind == "medic"]
    trucks = [a for a in model.schedule.agents if hasattr(a, "kind") and a.kind == "truck"]
    
    # Fire suppression priority
    if fires > len(trucks) * 2:
        recommendations.append({
            "priority": "high",
            "category": "fire_suppression",
            "recommendation": f"Deploy all {len(trucks)} trucks to fire suppression - {fires} active fires detected",
            "affected_agents": [str(t.unique_id) for t in trucks]
        })
    
    # Rescue operations priority
    urgent_survivors = len([a for a in model.schedule.agents 
                          if hasattr(a, "life_deadline") and a.life_deadline < 50])
    if urgent_survivors > 0:
        available_medics = len([m for m in medics if not getattr(m, "carrying", False)])
        recommendations.append({
            "priority": "critical",
            "category": "rescue_operations", 
            "recommendation": f"Deploy {available_medics} available medics to rescue {urgent_survivors} critical survivors",
            "affected_agents": [str(m.unique_id) for m in medics if not getattr(m, "carrying", False)]
        })
    
    # Resource management
    low_battery_drones = [d for d in drones if d.battery < 20]
    low_fuel_trucks = [t for t in trucks if t.fuel < 10]
    tired_medics = [m for m in medics if m.stamina < 30]
    
    if low_battery_drones or low_fuel_trucks or tired_medics:
        recommendations.append({
            "priority": "medium",
            "category": "resource_management",
            "recommendation": f"Send {len(low_battery_drones + low_fuel_trucks + tired_medics)} agents for resupply/recharge",
            "affected_agents": [str(a.unique_id) for a in low_battery_drones + low_fuel_trucks + tired_medics]
        })
    
    return recommendations

def predict_resource_depletion(model, time_horizon=30):
    """Predict when agents will run out of critical resources."""
    predictions = {}
    
    for agent in model.schedule.agents:
        if not hasattr(agent, "kind"):
            continue
        
        agent_id = str(agent.unique_id)
        predictions[agent_id] = {
            "agent_type": agent.kind,
            "current_status": get_operational_status(agent)
        }
        
        # Drone battery prediction
        if hasattr(agent, "battery"):
            current_battery = agent.battery
            # Estimate usage rate (movement + passive drain)
            estimated_usage_rate = 2  # Conservative estimate
            time_to_depletion = max(0, current_battery / estimated_usage_rate)
            
            predictions[agent_id].update({
                "resource_type": "battery",
                "current_level": current_battery,
                "depletion_time": time_to_depletion,
                "needs_attention": time_to_depletion < time_horizon * 0.3
            })
        
        # Truck fuel/resources prediction
        elif hasattr(agent, "fuel"):
            fuel_depletion = max(0, agent.fuel / 1.5)  # Fuel usage rate
            water_depletion = float('inf') if agent.water <= 0 else agent.water / 0.5
            tools_depletion = float('inf') if getattr(agent, "tools", 0) <= 0 else getattr(agent, "tools", 0) / 0.2
            
            earliest_depletion = min(fuel_depletion, water_depletion, tools_depletion)
            
            predictions[agent_id].update({
                "resource_type": "fuel/supplies",
                "fuel_time": fuel_depletion,
                "water_time": water_depletion,
                "tools_time": tools_depletion,
                "earliest_depletion": earliest_depletion,
                "needs_attention": earliest_depletion < time_horizon * 0.4
            })
        
        # Medic stamina prediction
        elif hasattr(agent, "stamina"):
            current_stamina = agent.stamina
            # Medics regenerate stamina, but work depletes it
            carrying_penalty = 2 if getattr(agent, "carrying", False) else 1
            net_stamina_rate = -1 * carrying_penalty + 1  # Regen rate
            
            if net_stamina_rate <= 0:
                time_to_exhaustion = current_stamina / abs(net_stamina_rate)
            else:
                time_to_exhaustion = float('inf')
            
            predictions[agent_id].update({
                "resource_type": "stamina",
                "current_level": current_stamina,
                "exhaustion_time": time_to_exhaustion,
                "carrying_load": getattr(agent, "carrying", False),
                "needs_attention": time_to_exhaustion < time_horizon * 0.5
            })
    
    return predictions